﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using Zeta.XmlEngine;

namespace Arcanum
{
    [XmlElement("Enchantment")]
    public class Enchantment : INotifyPropertyChanged
    {
        private ItemProperty _itemProperty;
        private bool _enabled = true;
        private bool _selected;
        private double _value;
        private double _maximum;
        private double _minimum;
        private string _variant;
        private string _original;
        private bool _suppressEvents = true;

        /// <summary>
        /// Type of enchantment
        /// </summary>
        [XmlElement("ItemProperty")]
        public ItemProperty ItemProperty
        {
            get { return _itemProperty; }
            set { SetProperty(ref _itemProperty, value); }
        }

        /// <summary>
        /// If enchantment should be shown in UI Controls
        /// </summary>
        public bool Enabled
        {
            get { return _enabled; }
            set { SetProperty(ref _enabled, value); }
        }

        /// <summary>
        /// If enchantment is selected in UI Controls
        /// </summary>
        public bool Selected
        {
            get { return _selected; }
            set { SetProperty(ref _selected, value); }
        }

        /// <summary>
        /// The minimum value for enchantment to be considered successfully found
        /// </summary>
        [XmlElement("Value")]
        public double Value
        {
            get { return _value; }
            set
            {
                var newValue = value;
                if (newValue < Minimum && Minimum > 0)
                    newValue = Minimum;
                if (newValue > Maximum && Maximum > 0)
                    newValue = Maximum;

                SetProperty(ref _value, newValue); 
                
            }
        }

        /// <summary>
        /// The maximum possible value
        /// </summary>
        [XmlElement("Maximum")]
        public double Maximum
        {
            get { return _maximum; }
            set { SetProperty(ref _maximum, value); }
        }

        /// <summary>
        /// The minimum possible value
        /// </summary>
        [XmlElement("Minimum")]
        public double Minimum
        {
            get { return _minimum; }
            set { SetProperty(ref _minimum, value); }
        }

        /// <summary>
        /// Information specific to an ItemProperty
        /// </summary>
        [XmlElement("Variant")]        
        public string Variant
        {
            get { return _variant; }
            set { SetProperty(ref _variant, value); }
        }

        /// <summary>
        /// The original (cleaned) UIElement.Text
        /// </summary>
        public string Original
        {
            get { return _original; }
            set { SetProperty(ref _original, value); }
        }

        /// <summary>
        /// Friendly Increment level between maximum and minimum
        /// </summary>
        public int Step
        {
            get
            {
                var result = 1;
                var range = Maximum - Minimum;

                if (range > 0 && range > 10)
                    result = (int)Math.Round(Math.Ceiling((range / 10) * 100) / 100, 0);

                return result;
            }
        }

        /// <summary>
        /// Combined ItemProperty + Variant
        /// </summary>
        [XmlElement("Name")]
        public string Name
        {
            get { return ItemProperty +" "+ _variant; }
            set { }  // DB requires a setter for saved properties             
        }

        /// <summary>
        /// INotifyPropertyChanged Event
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Set property and raise events in main thread
        /// </summary>
        protected virtual void SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            var fieldref = field;

            if (fieldref == null || !fieldref.Equals(value))
                field = value;

            if (PropertyChanged!=null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            var threadName = Thread.CurrentThread.ManagedThreadId == 1 ? "DB_Main" : Thread.CurrentThread.Name;
            var threadId = Thread.CurrentThread.ManagedThreadId;

            Logger.Debug("PropertyChanged {0} > {1} {2} by {3} ({4})",
                ItemProperty,
                propertyName,
                value,
                threadName,
                threadId);
        }

        /// <summary>
        /// Compare on ItemProperty Property only;
        /// </summary>
        public class ItemPropertyEquality : IEqualityComparer<Enchantment>
        {
            public static ItemPropertyEquality Comparer = new ItemPropertyEquality();

            public bool Equals(Enchantment x, Enchantment y)
            {
                if (ReferenceEquals(x, null) || ReferenceEquals(y, null))
                    return false;

                return x.ItemProperty == y.ItemProperty;
            }

            public int GetHashCode(Enchantment obj)
            {
                return ReferenceEquals(obj, null) ? 0 : obj.ItemProperty.GetHashCode();
            }
        }
        
        public override int GetHashCode()
        {
            var itemProperty = ItemProperty.GetHashCode();
            //var minimum = Minimum.GetHashCode();
            //var maximum = Maximum.GetHashCode();
            var extra = ReferenceEquals(Variant, null) ? 0 : Variant.GetHashCode();
            //var original = ReferenceEquals(Original, null) ? 0 : Original.GetHashCode();
            return itemProperty ^ extra;
        }

        public override bool Equals(object obj)
        {
            return !ReferenceEquals(obj, null) && GetHashCode().Equals(obj.GetHashCode());
        }

        public override string ToString()
        {
            return 
            string.Format("ItemProperty={0} Variant={1} Value={2} Min={3} Max={4} Original={5}",
                        ItemProperty, Variant, Value, Minimum, Maximum, Original);
        }
    }



}
