﻿using System;
using System.Windows;
using Zeta.Bot;
using Zeta.Common.Plugins;


namespace Arcanum
{
    public class Arcanum : IPlugin
    {
        private Arcanum()
        {
            Name = "Arcanum";
            Version = new Version(1, 1, 4);
            Author = "xzjv";
            Description = "Enchanting";
        }

        public string Name { get; set; }
        public Version Version { get; set; }
        public string Author { get; set; }
        public string Description { get; set; }
        public Window DisplayWindow { get; set; }

        public void OnPulse()
        {
          
        }

        public void OnInitialize()
        {
            BotMain.OnStop += ibot =>
            {
                if (IsEnabled)
                    UI.Attach();
            };
        }

        public void OnShutdown()
        {
            
        }

        public void OnEnabled()
        {
            Logger.Log("{0} v{1} by {2} Enabled!", Name, Version, Author);
            IsEnabled = true;
            UI.Attach();
        }

        public void OnDisabled()
        {
            Logger.Log("{0} v{1} by {2} Disabled!", Name, Version, Author);
            IsEnabled = false;
            UI.Detach();            
        }

        public bool IsEnabled { get; set; }
        public bool Equals(IPlugin other)
        {
            return other.Equals(this);
        }
    }
}