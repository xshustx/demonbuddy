﻿using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows;
using System.Windows.Data;
using Zeta.Common;
using Zeta.Common.Xml;
using Zeta.Game;
using Zeta.XmlEngine;


namespace Arcanum
{
    [XmlElement("ArcanumSettings")]
    public class ArcanumSettings : XmlSettings, INotifyPropertyChanged
    {
        private static object _syncLock = new object();
        public Commands Commands;
        private string _buttonText = "None Selected";
        private static ArcanumSettings _instance;
        private static string _battleTagName;
        private Enchantment _selectedEnchantment;
        private bool _isEnchanting;
        private FullyObservableCollection<Enchantment> _enchantOptions;
        public new event PropertyChangedEventHandler PropertyChanged = (sender, args) => { };

        public ArcanumSettings() : base(Path.Combine(SettingsDirectory, "Arcanum", BattleTagName, "Arcanum.xml"))
        {
            // Enable non-owner threads to change collection
            BindingOperations.EnableCollectionSynchronization(EnchantOptions, _syncLock);            
        }

        public string ButtonText
        {
            get { return _buttonText; }
            set
            {
                _buttonText = value;
                SetProperty(ref _buttonText, value); 
            }
        }

        public static ArcanumSettings Instance
        {
            get { return _instance ?? (_instance = new ArcanumSettings()); }
        }


        private static string BattleTagName
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_battleTagName) && ZetaDia.Service.Hero.IsValid)
                    _battleTagName = ZetaDia.Service.Hero.BattleTagName;
                return _battleTagName;
            }
        }

        public Enchantment SelectedEnchantment
        {
            get { return _selectedEnchantment; }
            set
            {                                
                SetProperty(ref _selectedEnchantment, value);
                Logger.Verbose("Selected {0}", value);
                Commands.UpdateButtonText.Execute();
            }
        }

        public List<Enchantment> SelectedEnchantments
        {
            get { return EnchantOptions.Where(o => o.Selected && o.Enabled).ToList(); }    
        }

        public string LocalizationAuthor
        {
            get { return Localization.GetString("LOCALIZATION_AUTHOR"); }
        }

        public string CurrentLocaleName
        {
            get { return Localization.IsDefault ? "Default" : Localization.CurrentCulture.Name; }
        }

        public bool IsEnchanting
        {
            get { return _isEnchanting; }
            set { SetProperty(ref _isEnchanting, value); }
        }
        
        [XmlElement("EnchantOptions")]
        public FullyObservableCollection<Enchantment> EnchantOptions
        {
            get { return _enchantOptions ?? (Application.Current.Dispatcher.Invoke(() => _enchantOptions = new FullyObservableCollection<Enchantment>())); }
            set { SetProperty(ref _enchantOptions, value); }
        }
        
        protected virtual void SetProperty<T>(ref T field, T value, [CallerMemberName] string propertyName = null)
        {
            if (field == null || !field.Equals(value))
                field = value;

            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));

            Logger.Debug("PropertyChanged {0} {1} by {2} ({3})", propertyName, value, Thread.CurrentThread.Name, Thread.CurrentThread.ManagedThreadId);
        }

    }

}

