﻿using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Input;
using Extensions = Zeta.Common.Extensions;


namespace Arcanum
{
    public class Commands
    {
        public static ArcanumSettings DataContext;

        static Commands()
        {
            DataContext = ArcanumSettings.Instance;
            BindDataEvents();
            BindThreadEvents();
        }

        private static void BindThreadEvents()
        {
            Enchanting.Worker.OnStarted += () => DataContext.IsEnchanting = true;
            Enchanting.Worker.OnStopped += () =>
            {
                DataContext.IsEnchanting = false;
                UpdateButtonText.Execute();
            };
        }

        private static void BindDataEvents()
        {
            DataContext.EnchantOptions.ChildElementPropertyChanged += args =>
            {
                var enchant = args.ChildElement as Enchantment;
                if (enchant == null)
                    return;

                // Select row if value has changed because user moved the slider or entered a new value into textbox
                if ((string)args.PropertyName == "Value" && !enchant.Selected && Thread.CurrentThread.ManagedThreadId == 1 && !BackgroundOperation)
                    enchant.Selected = true;                  

                if(enchant.Selected)
                    Logger.Verbose("Selected {0}", enchant);

                Logger.Debug("Child Changed: {0} Variant={1} Value={2}",
                    enchant.ItemProperty,
                    enchant.Variant,
                    enchant.Value);

                UpdateButtonText.Execute();
            };
        }

        public static ICommand ClearEnchantOptionsCommand
        {
            get
            {
                return new RelayCommand(p => Extensions.ForEach(DataContext.EnchantOptions, o =>
                {
                    o.Enabled = false;
                    o.Selected = false;
                }));
            }
        }

        public ICommand EnchantCommand
        {
            get
            {
                return new RelayCommand(p => Application.Current.Dispatcher.Invoke(() =>
                {
                    if (!Enchanting.Worker.IsRunning)
                    {
                        StartEnchantingCommand.Execute(p);
                    }
                    else
                    {
                        StopEnchantingCommand.Execute(p);
                    }
                }));
            }
        }

        public ICommand StartEnchantingCommand
        {
            get
            {
                return new RelayCommand(p => Application.Current.Dispatcher.Invoke(() =>
                {
                    if (!Enchanting.Worker.IsRunning)
                    {
                        
                        DataContext.SelectedEnchantments.ForEach(e => Logger.Log("Enchanting {0} >= {1}", e.ItemProperty, e.Value));
                        Enchanting.Enchant(DataContext.SelectedEnchantments);
                        DataContext.ButtonText = "Stop Enchanting";
                    }
                }));
            }
        }

        public ICommand StopEnchantingCommand
        {
            get
            {
                return new RelayCommand(p => Application.Current.Dispatcher.Invoke(() =>
                {
                    if (Enchanting.Worker.IsRunning)
                    {
                        Logger.Log("Stopping Enchanting");
                        Enchanting.Worker.Stop();
                    }
                }));
            }
        }

        public static ICommand UpdateButtonText
        {
            get
            {
                return new RelayCommand(p => Application.Current.Dispatcher.Invoke(() =>
                {
                    if (DataContext.IsEnchanting)
                    {
                        DataContext.ButtonText = "Stop Enchanting";
                        return;
                    }

                    var selected = DataContext.EnchantOptions.Where(o => o.Selected && o.Enabled).ToList();
                    if (selected.Any())
                    {
                        if (selected.Count == 1)
                        {
                            DataContext.ButtonText = "Enchant: " + (string.IsNullOrEmpty(selected.First().Variant) ? selected.First().ItemProperty.ToString() : selected.First().Variant) + "!";
                            return;
                        }

                        DataContext.ButtonText = string.Format("Enchant {0} things", selected.Count);
                        return;
                    }

                    DataContext.ButtonText = "None Selected";

                }));
            }
        }

        public ICommand ResetValuesToMaximumCommand
        {
            get
            {
                return new RelayCommand(p =>
                {
                    BackgroundOperation = true;
                    Extensions.ForEach(DataContext.EnchantOptions, o => o.Value = o.Maximum);
                    BackgroundOperation = false;
                });
            }
        }

        public static bool BackgroundOperation { get; set; }
    }

    public static class CommandExtensions
    {
        public static void Execute(this ICommand command, object param = null)
        {
            command.Execute(param);
        }
    }

}
