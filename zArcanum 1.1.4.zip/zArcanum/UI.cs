﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Markup;
using System.Windows.Media;
using zArcanum;
using Zeta.Game;

namespace Arcanum
{
    public class UI
    {
        public static Worker UIWorker = new Worker
        {
            WaitTime = 500
        };

        public static Worker PulseWorker = new Worker();
        public static TabItem TabItem;
        public static bool TimeoutEnabled = true;
        public static bool Injected;

        public static void Attach()
        {            
            if (!Injected)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    var uniformGrid = new UniformGrid
                    {
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        VerticalAlignment = VerticalAlignment.Top,
                        Height = 180,
                        Margin = new Thickness(0, 0, 10, 0)
                    };

                    TabItem = new TabItem
                    {
                        Header = "Arcanum",
                        Content = uniformGrid,
                        Foreground = new SolidColorBrush(Colors.White),
                    };

                    var tabs = Application.Current.MainWindow.FindName("tabControlMain") as TabControl;
                    if (tabs == null)
                        return;

                    tabs.Items.Add(TabItem);

                    var assemblyPath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

                    var pluginPath = Path.Combine(assemblyPath, "plugins");

                    if (assemblyPath == null)
                        return;

                    var xamlInterfaceFile = GetFile(pluginPath, "Arcanum.Settings.xaml");

                    if (!File.Exists(xamlInterfaceFile))
                        return;

                    var xamlContent = File.ReadAllText(xamlInterfaceFile);
                    xamlContent = ReplaceNamespace(xamlContent, "xmlns:arcanum=\"clr-namespace:Arcanum\"");
                    xamlContent = ReplaceNamespace(xamlContent, "xmlns:attach=\"clr-namespace:AttachedCommandBehavior\"");

                    var mainControl = (UserControl)XamlReader.Load(new MemoryStream(Encoding.UTF8.GetBytes(xamlContent)));

                    mainControl.DataContext = ArcanumSettings.Instance;

                    uniformGrid.Children.Add(mainControl);

                    Injected = true;

                });                
            }
            
            UIWorker.Start(ThreadTask_UpdateValidEnchantsControl);
        }

        public static string GetFile(string startDirectory, string fileName)
        {
            return GetFile(startDirectory, new List<string>() { fileName });
        }

        internal static string GetFile(string startDirectory, ICollection<string> fileNames)
        {
            var dirExcludes = new HashSet<string>
            {
                ".svn",
                "obj",
                "bin",
                "debug"
            };

            var queue = new Queue<string>();

            queue.Enqueue(startDirectory);

            Func<string, string> last = input => input.Split('\\').Last().ToLower();

            Func<IEnumerable<string>, string, bool> contains = (haystack, needle) =>
            {
                return haystack.Contains(needle, StringComparer.Create(Thread.CurrentThread.CurrentCulture, true));
            };

            while (queue.Count > 0)
            {
                startDirectory = queue.Dequeue();
                try
                {
                    foreach (var subDir in Directory.GetDirectories(startDirectory))
                    {
                        if (contains(dirExcludes, last(subDir))) continue;
                        queue.Enqueue(subDir);
                    }
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine(ex);
                }
                string[] files = null;
                try
                {
                    files = Directory.GetFiles(startDirectory);
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine(ex);
                }
                if (files != null)
                {
                    foreach (var filePath in files)
                    {
                        if (!contains(fileNames, last(filePath))) continue;
                        return filePath;
                    }
                }
            }
            return string.Empty;
        }

        internal static void Detach()
        {
            UIWorker.Stop();

            Application.Current.Dispatcher.Invoke(() =>
            {
                var tabs = Application.Current.MainWindow.FindName("tabControlMain") as TabControl;
                if (tabs == null)
                    return;

                tabs.Items.Remove(TabItem);
            });
        }

        /// <summary>
        /// Update Enchants Control without disturbing user entered/saved values
        /// </summary>
        private static bool ThreadTask_UpdateValidEnchantsControl()
        {
            try
            {
                Thread.Sleep(500);

                if (Enchanting.Worker.IsRunning || !IsArcanumTabSelected())
                {
                    Logger.Debug("Worker IsRunning={0} ArcanumTabSelected={1}", Enchanting.Worker.IsRunning, IsArcanumTabSelected());
                    return false;
                }

                using (new MemoryHelper())
                {
                    if (!ZetaDia.IsInGame)
                    {
                        Logger.Verbose("Not in Game");
                        return false;
                    }

                    switch (Enchanting.State)
                    {
                        case Enchanting.EnchantingState.NotEnchanting:
                        case Enchanting.EnchantingState.NoItemSelected:

                            if (ArcanumSettings.Instance.EnchantOptions.Any(o => o.Enabled))
                                Commands.ClearEnchantOptionsCommand.Execute();

                            Logger.Verbose("Not Enchanting");

                            return false;
                    }

                    var validAffixes = Enchanting.ValidAffixes;
                    var controlItems = ArcanumSettings.Instance.EnchantOptions;

                    if (validAffixes == null || !validAffixes.Any())
                    {
                        Logger.Verbose("Valid Affixes returned null");
                        return false;
                    }

                    controlItems.Clear();
                    controlItems.AddRange(validAffixes);

                    //validAffixes = validAffixes.ToList();
                    //Logger.Log("ValidAffixes={0} ControlItems={1} Enabled={1}", validAffixes.Count, controlItems.Count, controlItems.Count(e => e.Enabled));

                    //foreach (var enchantment in controlItems)
                    //{
                    //    var updatedEnchant = validAffixes.FirstOrDefault(o => o.Equals(enchantment));

                    //    if (updatedEnchant != null)
                    //    {
                    //        // Enchant is already in Display collection, update it and remove from affixes list.
                    //        if (!enchantment.Enabled)
                    //        {
                    //            enchantment.Enabled = true;
                    //            enchantment.Maximum = updatedEnchant.Maximum;
                    //            enchantment.Minimum = updatedEnchant.Minimum;
                    //            enchantment.Variant = updatedEnchant.Variant;
                    //            enchantment.Original = updatedEnchant.Original;
                    //        }
                    //        validAffixes.Remove(enchantment);
                    //    }
                    //    else
                    //    {
                    //        if (enchantment.Enabled)
                    //        {
                    //            enchantment.Enabled = false;
                    //        }
                    //    }
                    //}

                    //// Everything that remains in the validAffixes is not already in the display collection so add them 
                    //controlItems.AddRange(validAffixes);

                }
            }
            catch (Exception ex)
            {     
                Logger.Debug("Error {0}", ex);
            }
            return false;
        }

        private static bool IsArcanumTabSelected()
        {
            return Application.Current.Dispatcher.Invoke(() => TabItem.IsSelected);
        }

        /// <summary>
        /// Required for dynamic loading of xaml
        /// DB adds _9872398723 etc to DLL filenames on compile
        /// So xaml assembly references need to be updated.
        /// </summary>
        private static string ReplaceNamespace(string xaml, string xmlns)
        {
            var asmName = Assembly.GetExecutingAssembly().GetName().Name;
            var newxmlns = xmlns.Insert(xmlns.Length - 1, ";assembly=" + asmName);
            return xaml.Replace(xmlns, newxmlns);
        }


    }

}
