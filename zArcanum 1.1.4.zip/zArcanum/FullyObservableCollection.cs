﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;

namespace Arcanum
{
    /// <summary>
    /// Surprisingly, the default ObservableCollection doesnt handle changed property events on objects within collection
    /// </summary>
    public class FullyObservableCollection<T> : ObservableCollection<T>
    {
        public delegate void ChildElementPropertyChangedEventHandler(ChildElementPropertyChangedEventArgs e);

        public event ChildElementPropertyChangedEventHandler ChildElementPropertyChanged;

        private void OnChildElementPropertyChanged(object childelement, PropertyChangedEventArgs propertyChangedEventArgs)
        {
            if (ChildElementPropertyChanged != null)
            {
                ChildElementPropertyChanged(new ChildElementPropertyChangedEventArgs(childelement, propertyChangedEventArgs));
            }
        }

        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            base.OnCollectionChanged(e);
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                foreach (T item in e.NewItems)
                {
                    var convertedItem = item as INotifyPropertyChanged;
                    if (convertedItem != null)
                        convertedItem.PropertyChanged += convertedItem_PropertyChanged;
                }
            }
            else if (e.Action == NotifyCollectionChangedAction.Remove)
            {
                foreach (T item in e.OldItems)
                {
                    var convertedItem = item as INotifyPropertyChanged;
                    if (convertedItem != null)
                        convertedItem.PropertyChanged -= convertedItem_PropertyChanged;
                }
            }
        }

        private void convertedItem_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {            
            OnChildElementPropertyChanged(sender, e);
        }

        protected override void ClearItems()
        {
            foreach (T unknown in Items)
            {
                var item = (INotifyPropertyChanged) unknown;
                item.PropertyChanged -= convertedItem_PropertyChanged;
            }

            base.ClearItems();
        }

        public class ChildElementPropertyChangedEventArgs : EventArgs
        {
            public ChildElementPropertyChangedEventArgs(object item, PropertyChangedEventArgs e)
            {                
                ChildElement = item;
                PropertyName = e.PropertyName;
            }

            public object ChildElement { get; set; }
            public object PropertyName { get; set; }
        }
    }
}