﻿using System;
using System.Windows.Input;

namespace Arcanum
{
    public class RelayCommand : ICommand
    {
        public RelayCommand(Action<object> execute)
        {
            _execute = execute;
        }

        public bool CanExecute(object parameter)
        {
            return _execute != null;
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged;
        private readonly Action<object> _execute;
    }
}
