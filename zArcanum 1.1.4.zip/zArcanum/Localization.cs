﻿#region

using System.Collections.Generic;
using System.Globalization;
using System.Linq;

#endregion

namespace Arcanum
{
    public static class Localization
    {
        public static Dictionary<string, Dictionary<string, string>> LocalizedDictionaries = new Dictionary<string, Dictionary<string, string>>
        {
            {
                "default", new Dictionary<string, string>
                {
                    {"LOCALIZATION_AUTHOR", "xzjv"},
                    {"STATUS_PLACEITEM", "place an item"},
                    {"STATUS_SELECTPROPERTYREPLACE", "select a property to replace"},
                    {"STATUS_SELECTPROPERTY", "select property"},
                    {"STATUS_REPLACEPROPERTY", "replace property"},
                    {"REGEX_PROPERTIES", @"(?<value>[\d\.,]+)(?<=[^\.])|(?<1>% Life)|(?<2>Armor)|(?<3>Critical Hit Chance)|(?<4>Critical Hit Damage)|Increases (?<5>.*) Damage|(?<6>Life per Spirit)|(?<7>Dexterity)|(?<8>Strength)|(?<9>Intelligence)|(?<10>Vitality)|(?<11>Area Damage)|(?<12>cooldown)|(?<13>resource costs)|(?<14>Durability)|(?<15>Physical Resist)|(?<16>Cold Resist)|(?<17>Fire Resist)|(?<18>Lightning Resist)|(?<19>Arcane Resist)|(?<20>Poison Resist)|(?<21>Extra Gold)|(?<22>damage per hit)|(?<23>Health Pickup)|(?<24>Chance to Chill)|(?<25>Ignores Durability)|(?<26>Potions Grant)|(?<27>Level Req)|(?<28>Movement)|(?<29>All Elements)|(?<30>Monster kills)|(?<31>Immobilize)|(?<32>Blind)|(?<33>Control Impair)|(?<34>Cold skills)|(?<35>Fire skills)|(?<36>Holy skills)|(?<37>Lightning skills)|(?<38>Poison skills)|(?<39>Physical skills)|(?<40>Wrath Regen)|(?<41>Attack Speed)|(?<42>Life per Hit)|(?<43>damage from elites)|(?<44>Bleed)|(?<45>Hatred Regen)|(?<46>Sockets)|(?<!\]%|%)(?<47> Fire Damage| Arcane Damage| Poison Damage| Lightning Damage| Cold Damage| Holy Damage| Damage)(?!\sper|\.)|(?<48>Life per Wrath)|(?<49>Maximum Wrath)|(?<50>Life per Fury)|(?<51>Spirit Regen)|(?<52>damage against elites)|(?<53>Life after Each)|(?<54>Maximum Mana)|(?<55>Maximum Arcane)|(?<56>damage from melee)|(?<57>damage from ranged)|(?<58>Maximum Spirit)|(?<59>Maximum Fury)|(?<60>Chance to Block)|(?<61>Chance to Fear)|(?<62>Chance to Stun)|(?<63>Chance to Freeze)|(?<64>Chance to Slow)|(?<65>Chance to Knock)|(?<66>Regenerates)|(?<67>Maximum Discipline)|(?<68>Critical Hits grant)|(?<69>Arcane skills)|(?<70>Mana Regeneration)|(?<71> Damage(?!\sper|\.))" }
                }
            },
            {
                "ko-KR", new Dictionary<string, string>
                {
                    {"LOCALIZATION_AUTHOR", "RohMuHyun"},
                    {"STATUS_PLACEITEM", "아이템을 올려놓으십시오"},
                    {"STATUS_SELECTPROPERTYREPLACE", "교체할 속성을 선택하십시오"},
                    {"STATUS_SELECTPROPERTY", "속성 선택"},
                    {"STATUS_REPLACEPROPERTY", "속성 교체"},
                    {"REGEX_PROPERTIES", @"(?<value>[\d\.,]+)(?<=[^\.])|(?<1>생명력)|(?<2>방어도)|(?<3>극대화 확률)|(?<4>극대화 피해)|(?<5>.*)로 주는 피해|(?<6>소모한 공력 1당 생명력)|(?<7>민첩)|(?<8>힘)|(?<9>지능)|(?<10>활력)|(?<11>광역 피해)|(?<12>재사용 대기시간)|(?<13>자원 소모량)|(?<14>Durability)|(?<15>물리 저항)|(?<16>냉기 저항)|(?<17>화염 저항)|(?<18>번개 저항)|(?<19>비전 저항)|(?<20>독 저항)|(?<21>적에게서 얻는 금화)|(?<22>공격자에게 적중 시)|(?<23>획득 반경)|(?<24>적중 시 오한)|(?<25>내구도 감소 무시)|(?<26>생명의 구슬과 물약으로)|(?<27>요구 레벨)|(?<28>이동 속도)|(?<29>모든 원소)|(?<30>적을 처치하고 얻는)|(?<31>적중 시 이동 불가)|(?<32>적중 시 실명)|(?<33>제어 방해 효과의 지속시간)|(?<34>냉기 기술로)|(?<35>화염 기술로)|(?<36>신성 기술로)|(?<37>번개 기술로)|(?<38>독 기술로)|(?<39>물리 기술로)|(?<40>진노 생성량)|(?<41>공격 속도)|(?<42>적중 시 생명력)|(?<43>정예에게 받는 피해)|(?<44>확률로 출혈)|(?<45>증오 회복량)|(?<46>홈)|(?<47>화염 무기 공격력|비전 무기 공격력|독 무기 공격력|번개 무기 공격력|냉기 무기 공격력|신성 무기 공격력|무기 공격력)(?<!\]%|%)(?!\sper|\.)|(?<48>소모한 진노 1당 생명력)|(?<49>최대 진노)|(?<50>소모한 분노 1당 생명력)|(?<51>공력 회복량)|(?<52>정예에게 주는 피해)|(?<53>처치 시 생명력)|(?<54>최대 마나)|(?<55>최대 비전력)|(?<56>근접 공격으로 받는)|(?<57>원거리 공격으로 받는)|(?<58>최대 공력)|(?<59>최대 분노)|(?<60>방패막기 확률)|(?<61>적중 시 공포)|(?<62>적중 시 기절)|(?<63>적중 시 빙결)|(?<64>적중 시 감속)|(?<65>적중 시 밀치기)|(?<66>초당 생명력)|(?<67>최대 절제)|(?<68>극대화 적중 시 비전력)|(?<69>비전 기술로)|(?<70>마나 회복량)|(?<71>(?!\sper|\.)피해)" }
                }
            },
            {
             "it-IT", new Dictionary<string, string>
                {
                    {"LOCALIZATION_AUTHOR", "SoftWord"},
                    {"STATUS_PLACEITEM", "colloca un oggetto per incantarlo"},
                    {"STATUS_SELECTPROPERTYREPLACE", "seleziona una proprietà da sostituire"},
                    {"STATUS_SELECTPROPERTY", "seleziona proprietà"},
                    {"STATUS_REPLACEPROPERTY", "sostituisci proprietà"},
                    {"REGEX_PROPERTIES", @"(?<value>[\d\.,]+)(?<=[^\.])|(?<1>% di punti vita)|(?<2>Armatura)|(?<3>Probabilità di colpo critico aumentata del)|(?<4>Danni da colpo critico aumentati del)|Aumenta i danni di (?<5>.*)|(?<6>vita per Spirito)|(?<7>Destrezza)|(?<8>Forza)|(?<9>Intelligenza)|(?<10>Vitalità)|(?<11>di danni ad area per colpo)|(?<12>Riduce il tempo di recupero di tutte le abilità del)|(?<13>tutti i costi in risorse)|(?<14>Non subisce perdite di integrità)|(?<15>resistenza fisica)|(?<16>resistenza al freddo)|(?<17>resistenza al fuoco)|(?<18>resistenza al fulmine)|(?<19>resistenza arcana)|(?<20>resistenza al veleno)|(?<21>di oro aggiuntivo recuperato dai nemici)|(?<22>Gli assalitori in mischia e a distanza subiscono)|(?<23>Aumenta il raggio di raccolta di oro e globi di cura di)|(?<24>probabilità di gelare)|(?<25>Ignores Durability)|(?<26>Globi di cura e pozioni ripristinano)|(?<27>Requisito di livello ridotto di)|(?<28>velocità di movimento)|(?<29>resistenza a tutti gli elementi)|(?<30>L'uccisione dei mostri conferisce)|(?<31>probabilità di immobilizzare)|(?<32>probabilità di accecare)|(?<33>la durata degli effetti debilitanti)|(?<34>freddo)|(?<35>fuoco)|(?<36>sacri)|(?<37>fulmine)|(?<38>veleno)|(?<39>fisiche)|(?<40>Wrath Regen)|(?<41>velocità d'attacco)|(?<42>Vita per colpo)|(?<43>Riduce i danni inflitti dagli élite del)|(?<44>di provocare sanguinamento per danni pari al)|(?<45>Hatred Regen)|(?<46>Castoni)|(?<!\]%|%)(?<47> danni da fuoco| danni arcani| danni da veleno| danni da fulmine| danni da freddo| danni da sacri| danni$)(?!\sper|\.)|(?<48>punti vita per uccisione)|(?<49>Maximum Wrath)|(?<50>punti vita per Furia consumata)|(?<51>Spirit Regen)|(?<52>i danni inflitti agli élite)|(?<53>Life after Each)|(?<54>Maximum Mana)|(?<55>Maximum Arcane)|(?<56>Riduce i danni subiti dagli attacchi in mischia del )|(?<57>Riduce i danni subiti dagli attacchi a distanza del)|(?<58>Maximum Spirit)|(?<59>Furia massima)|(?<60>probabilità di parata)|(?<61>probabilità di spaventare)|(?<62>probabilità di stordire)|(?<63>probabilità di congelare)|(?<64>di probabilità di rallentare colpendo)|(?<65>probabilità di respingere)|(?<66>punti vita al secondo)|(?<67>Maximum Discipline)|(?<68>I colpi critici conferiscono)|(?<69>danni inflitti da abilità arcane)|(?<70>Mana Regeneration)|(?<71> danni$(?!\sper|\.))|(?<73>Velocità d'attacco aumentata del)" }
                }
            },
            {
                "zh-Hans", new Dictionary<string, string>
                {
                    {"LOCALIZATION_AUTHOR", "Meiam"},
                    {"STATUS_PLACEITEM", "放置一项物品"},
                    {"STATUS_SELECTPROPERTYREPLACE", "选择要替换的属性"},
                    {"STATUS_SELECTPROPERTY", "选择属性"},
                    {"STATUS_REPLACEPROPERTY", "替换属性"},
                    {"REGEX_PROPERTIES", @"(?<value>[\d\.,]+)(?<=[^\.])|(?<1>% 生命值)|(?<2>护甲)|(?<3>暴击几率)|(?<4>暴击伤害)|(?<5>.*) 的伤害提高|(?<6>每消耗1点内力获得)|(?<7>敏捷)|(?<8>力量)|(?<9>智力)|(?<10>体能)|(?<11>范围伤害)|(?<12>冷却)|(?<13>消耗降低)|(?<14>耐久)|(?<15>物理抗性)|(?<16>冰霜抗性)|(?<17>火焰抗性)|(?<18>闪电抗性)|(?<19>奥术抗性)|(?<20>毒性抗性)|(?<21>额外金币)|(?<22>每次被命中对远程和近战攻击者造成)|(?<23>生命球)|(?<24>机率造成)|(?<25>无视耐久)|(?<26>恢复量)|(?<27>等级需求降低)|(?<28>移动速度)|(?<29>全元素抗性)|(?<30>消灭)|(?<31>定身)|(?<32>致盲)|(?<33>控制类)|(?<34>冰霜技能)|(?<35>火焰技能)|(?<36>神圣技能)|(?<37>闪电技能)|(?<38>毒性技能)|(?<39>物理技能)|(?<40>消耗怒气恢复)|(?<41>攻击速度)|(?<42>击中回复生命)|(?<43>受到的精英怪物伤害降低)|(?<44>流血)|(?<45>憎恨值提高)|(?<46>镶孔)|(?<!\]%|%)(?<47>火焰伤害|奥术伤害|毒性伤害|闪电伤害|冰霜伤害|神圣伤害|伤害)(?!\sper|\.)|(?<48>每消耗1点愤怒值获得)|(?<49>愤怒值上限)|(?<50>每秒恢复的愤怒值提高)|(?<51>内力提高)|(?<52>对精英敌人造成的伤害提高)|(?<53>击杀生命恢复)|(?<54>法力值上限)|(?<55>秘能上限)|(?<56>从近战攻击中受到的伤害降低)|(?<57>从远程攻击中受到的伤害降低)|(?<58>内力上限)|(?<59>怒气上限)|(?<60>格挡几率)|(?<61>产生恐惧)|(?<62>产生昏迷)|(?<63>产生冰冻)|(?<64>产生减速)|(?<65>产生击退)|(?<66>每秒回复)|(?<67>戒律值上限)|(?<68>爆击时获得)|(?<69>秘法技能)|(?<70>每秒恢复的法力值提高)|(?<71>伤害(?!\sper|\.))|(?<72>产生寒冷)" }
                }
            }
        };

        public static string GetString(string key)
        {
            return CurrentResources.ContainsKey(key) ? CurrentResources[key] : string.Empty;
        }

        private static CultureInfo _currentCulture;

        static Localization()
        {
            CurrentCulture = CultureInfo.CurrentUICulture;
            UpdateCurrentResource(CurrentCulture.Name);
        }

        public static CultureInfo CurrentCulture
        {
            get { return _currentCulture; }
            set
            {
                if (!Equals(value, _currentCulture))
                {
                    UpdateCurrentResource(value.Name);
                    _currentCulture = value;
                }
            }
        }

        public static Dictionary<string, string> CurrentResources { get; private set; }

        public static bool IsDefault { get; private set; }

        private static void UpdateCurrentResource(string culture)
        {
            if (LocalizedDictionaries.ContainsKey(culture))
            {
                CurrentResources = LocalizedDictionaries[culture];
                IsDefault = false;
                return;
            }

            if ((CurrentResources == null || !CurrentResources.Any()) && LocalizedDictionaries.ContainsKey("default"))
            {
                CurrentResources = LocalizedDictionaries["default"];
                IsDefault = true;
            }
                
        }
    }
}