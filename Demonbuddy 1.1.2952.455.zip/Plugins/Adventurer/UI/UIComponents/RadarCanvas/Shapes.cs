﻿namespace Adventurer.UI.UIComponents.RadarCanvas
{
    public static class Shapes
    {
        //public class Rectangle : DrawingVisual
        //{
        //    public Rectangle()
        //    {
        //        using (DrawingContext dc = RenderOpen())
        //        {
        //            // Black ellipse with blue border
        //            dc.DrawEllipse(Brushes.Black,
        //                new Pen(Brushes.Blue, 3),        // Border
        //                new Point(120, 120), 20, 40);    // Center & radius

        //            // Red rectangle with green border
        //            dc.DrawRectangle(Brushes.Red,
        //                new Pen(Brushes.Green, 4),       // Border
        //                new Rect(new Point(10, 10), new Point(80, 80)));    // Corners
        //        }
        //    }
        //}
    }
}
