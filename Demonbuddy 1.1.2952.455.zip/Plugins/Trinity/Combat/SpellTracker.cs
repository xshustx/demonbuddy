﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Trinity.Technicals;
using Zeta.Game.Internals.Actors;

namespace Trinity.Combat
{
    /// <summary>
    /// Provides facilities to track DoT and duration/expiration spells on monsters
    /// </summary>
    public class SpellTracker : IEquatable<SpellTracker>
    {
        private const int AnyRune = -999;

        public int ACDGuid { get; set; }
        public SNOPower Power { get; set; }
        public DateTime Expiration { get; set; }

        internal static HashSet<SpellTracker> TrackedUnits { get; set; }
        private static Thread MaintenanceThread;

        internal static void TrackSpellOnUnit(SpellTracker trackedUnit)
        {
            if (!TrackedUnits.Any(t => t.Equals(trackedUnit)))
            {
                TrackedUnits.Add(trackedUnit);
            }
        }

        internal static void TrackSpellOnUnit(int acdGuid, SNOPower power)
        {
            try
            {
                float duration = -1;
                if (CacheData.Hotbar.ActivePowers.Contains(power))
                {
                    // Can't track a spell that isn't equipped
                    var skill = CacheData.Hotbar.GetSkill(power);
                    var spell = TrackedSpells.FirstOrDefault(s => s.Equals(new TrackedSpell(power, skill.RuneIndex)) || s.Equals(new TrackedSpell(power, AnyRune)));
                    if (spell != null)
                        duration = spell.Duration;
                }

                var anyRune = TrackedSpells.FirstOrDefault(s => s.Power == power  && s.RuneIndex == AnyRune);

                if (duration == -1 && anyRune != null)
                    duration = anyRune.Duration;

                if (duration > 0)
                {
                    Logger.Log(TrinityLogLevel.Verbose, LogCategory.Behavior, "Tracking unit {0} with power {1} for duration {2:0.00}", acdGuid, power, duration);
                    TrackSpellOnUnit(new SpellTracker()
                       {
                           ACDGuid = acdGuid,
                           Power = power,
                           Expiration = DateTime.UtcNow.AddMilliseconds(duration)
                       });
                }
            }
            catch (Exception ex)
            {
                Logger.LogNormal("Exception in TrackSpellOnUnit: {0}", ex.ToString());
            }
        }

        /// <summary>
        /// Checks if a unit is currently being tracked with a given SNOPower. When the spell is properly configured, this can be used to set a "timer" on a DoT re-cast, for example.
        /// </summary>
        /// <param name="acdGuid"></param>
        /// <param name="power"></param>
        /// <returns></returns>
        public static bool IsUnitTracked(int acdGuid, SNOPower power)
        {
            return TrackedUnits.Any(t => t.ACDGuid == acdGuid && t.Power == power);
        }

        /// <summary>
        /// Checks if a unit is currently being tracked with a given SNOPower. When the spell is properly configured, this can be used to set a "timer" on a DoT re-cast, for example.
        /// </summary>
        /// <param name="unit"></param>
        /// <param name="power"></param>
        /// <returns></returns>
        public static bool IsUnitTracked(TrinityCacheObject unit, SNOPower power)
        {
            if (unit == null)
                return false;

            if (unit.Type != TrinityObjectType.Unit)
                return false;
            bool result = TrackedUnits.Any(t => t.ACDGuid == unit.ACDGuid && t.Power == power);
            //if (result)
            //    Technicals.Logger.LogNormal("Unit {0} is tracked with power {1}", unit.ACDId, power);
            //else
            //    Technicals.Logger.LogNormal("Unit {0} is NOT tracked with power {1}", unit.ACDId, power);
            return result;
        }

        #region Static Constructor
        static SpellTracker()
        {
            TrackedUnits = new HashSet<SpellTracker>();
            PopulateTrackedSpells();

            MaintenanceThread = new Thread(RunMaintenance)
            {
                Name = "Trinity SpellTracker",
                IsBackground = true,
                Priority = ThreadPriority.Lowest
            };
            MaintenanceThread.Start();

        }
        #endregion

        #region Background Maintenance Thread
        private static void RunMaintenance()
        {
            while (true)
            {
                try
                {
                    Thread.Sleep(100);
                    if (TrackedUnits.Any())
                    {
                        lock (TrackedUnits)
                        {
                            //TrackedUnits.RemoveWhere(t => t.Expiration < DateTime.UtcNow);
                            var units = TrackedUnits.Where(t => t.Expiration < DateTime.UtcNow);
                            foreach (var unit in units.ToList())
                            {
                                //Technicals.Logger.LogNormal("Removing unit {0} from TrackedUnits ({1}, {2})", unit.ACDId, unit.Expiration.Ticks, DateTime.UtcNow.Ticks);
                                TrackedUnits.Remove(unit);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogNormal("Exception in SpellTracker Maintenance: {0}", ex.ToString());
                }
            }
        }
        #endregion

        #region IEquatable Implimentation
        public bool Equals(SpellTracker other)
        {
            return this.ACDGuid == other.ACDGuid && this.Power == other.Power;
        }
        #endregion

        private static HashSet<TrackedSpell> TrackedSpells = new HashSet<TrackedSpell>();

        /// <summary>
        /// Populates the static TrackedSpells Hashset. Called once from Static Constructor. Do not call anywhere else...
        /// </summary>
        private static void PopulateTrackedSpells()
        {
            // new TrackedSpell(SNOPower, RuneIndex, MillsecondsDuration)
            // Use RuneIndex = AnyRune for "default" or any rune index

            TrackedSpells.Clear();

            // Barbarian 
            // TBD, maybe Rend is a good candidate?

            // Monk
            TrackedSpells.Add(new TrackedSpell(SNOPower.Monk_ExplodingPalm, AnyRune, 9000f));

            TrackedSpells.Add(new TrackedSpell(SNOPower.Monk_FistsofThunder, 0, 6000f)); // Static Charge

            // Wizard
            // TBD

            // Witch Doctor
            TrackedSpells.Add(new TrackedSpell(SNOPower.Witchdoctor_Haunt, 0, 6000f));
            TrackedSpells.Add(new TrackedSpell(SNOPower.Witchdoctor_Haunt, 1, 6000f));
            TrackedSpells.Add(new TrackedSpell(SNOPower.Witchdoctor_Haunt, 2, 6000f));
            TrackedSpells.Add(new TrackedSpell(SNOPower.Witchdoctor_Haunt, 3, 6000f));
            TrackedSpells.Add(new TrackedSpell(SNOPower.Witchdoctor_Haunt, 4, 2000f)); // WD, Resentful Spirit

            TrackedSpells.Add(new TrackedSpell(SNOPower.Witchdoctor_Locust_Swarm, AnyRune, 8000f));

            TrackedSpells.Add(new TrackedSpell(SNOPower.DemonHunter_MarkedForDeath, AnyRune, 10f));

            // Demon Hunter
            TrackedSpells.Add(new TrackedSpell(SNOPower.DemonHunter_MarkedForDeath, AnyRune, 30000f));
            // TBD
        }


        public class TrackedSpell : IEquatable<TrackedSpell>
        {
            /// <summary>
            /// The SNO Power
            /// </summary>
            public SNOPower Power { get; set; }
            /// <summary>
            /// The rune index
            /// </summary>
            public int RuneIndex { get; set; }
            /// <summary>
            /// Duration of Tracked Spell in Millseconds
            /// </summary>
            public float Duration { get; set; }

            public TrackedSpell(SNOPower power, int runeIndex, float duration)
            {
                Power = power;
                RuneIndex = runeIndex;
                Duration = duration;
            }

            public TrackedSpell(SNOPower power, int runeIndex)
            {
                Power = power;
                RuneIndex = runeIndex;
            }

            public bool Equals(TrackedSpell other)
            {
                return Power == other.Power && (RuneIndex == other.RuneIndex || RuneIndex == AnyRune || other.RuneIndex == AnyRune);
            }
        }
    }

}
