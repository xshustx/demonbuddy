﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Buddy.Coroutines;
using TrinityCoroutines.Resources;
using Zeta;
using Zeta.Bot;
using Zeta.Common;
using Zeta.TreeSharp;
using Zeta.Common;
using Zeta.Bot;
using Zeta.Bot.Navigation;
using Zeta.Game;
using Zeta.Game.Internals;
using Zeta.Game.Internals.Actors;
using Logger = Trinity.Technicals.Logger;

namespace TrinityCoroutines
{
    public class PutItemsInStash
    {
        public static async Task<bool> Execute(List<ACDItem> stashCandidates)
        {
            Logger.Log("PutItemsInStash Started! (ACDItems)");

            if (!ZetaDia.IsInGame || !ZetaDia.IsInTown)
                return false;

            if (Town.Locations.Stash.Distance(ZetaDia.Me.Position) > 3f)
            {
                await MoveToAndInteract.Execute(Town.Locations.Stash, Town.ActorIds.Stash, 8f);
            }

            var stash = Town.Actors.Stash;
            if (stash == null)
            {
                Logger.Log("[PutItemsInStash] Unable to find Stash");
                return false;
            }

            if (!UIElements.StashWindow.IsVisible && Town.Locations.Stash.Distance(ZetaDia.Me.Position) <= 10f)
            {
                Logger.Log("[PutItemsInStash] Stash window not open, interacting");
                stash.Interact();
            }

            foreach (var item in stashCandidates)
            {
                try
                {
                    if (!item.IsValid || item.IsDisposed)
                    {
                        Logger.LogVerbose("[PutItemsInStash] An ACDItem was invalid, unable to put it in stash.");
                        continue;
                    }

                    ZetaDia.Me.Inventory.QuickStash(item);                    
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex.ToString());
                }
            }

            await Coroutine.Sleep(1000);
            Logger.Log("[PutItemsInStash] Finished!");
            return true;
        }

        public static async Task<bool> Execute(List<int> annIds)
        {
            Logger.Log("PutItemsInStash Started! ({0} AnnIds)", annIds.Count);

            if (!ZetaDia.IsInGame || !ZetaDia.IsInTown)
                return false;

            if (Town.Locations.Stash.Distance(ZetaDia.Me.Position) > 3f)
            {
                await MoveToAndInteract.Execute(Town.Locations.Stash, Town.ActorIds.Stash, 8f);
            }

            var stash = Town.Actors.Stash;
            if (stash == null)
            {
                Logger.Log("[PutItemsInStash] Unable to find Stash");
                return false;
            }

            if (!UIElements.StashWindow.IsVisible && Town.Locations.Stash.Distance(ZetaDia.Me.Position) <= 10f)
            {
                Logger.Log("[PutItemsInStash] Stash window not open, interacting");
                stash.Interact();
            }

            foreach (var item in ZetaDia.Me.Inventory.Backpack.Where(i => annIds.Contains(i.AnnId)))
            {
                try
                {
                    if (!item.IsValid || item.IsDisposed)
                    {
                        Logger.LogVerbose("[PutItemsInStash] An ACDItem was invalid, unable to put it in stash.");
                        continue;
                    }

                    ZetaDia.Me.Inventory.QuickStash(item);
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex.ToString());
                }
            }

            await Coroutine.Sleep(1000);
            Logger.Log("[PutItemsInStash] Finished!");
            return true;
        }

    }
}
