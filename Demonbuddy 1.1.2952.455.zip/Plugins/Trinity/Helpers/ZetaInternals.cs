﻿using System;
using System.Reflection;
using Zeta.Game;
using Zeta.Game.Internals;

namespace Trinity.Helpers
{
    public static class ZetaInternals
    {
        public static Type Type;
        public static FieldInfo[] Fields;
        public static PropertyInfo[] Properites;        

        static ZetaInternals()
        {
            Update();
        }

        public static void Update()
        {
            Type = typeof(ZetaDia);
            Fields = Type.GetFields(BindingFlags.NonPublic | BindingFlags.Static);
            Properites = Type.GetProperties(BindingFlags.NonPublic | BindingFlags.Static);

            foreach (var propInfo in Properites)
            {
                if (propInfo.PropertyType == typeof (ActivePlayerData))
                {
                    ActivePlayerData = propInfo.GetValue(null) as ActivePlayerData;
                    break;
                }
            }
        }

        public static ActivePlayerData ActivePlayerData { get; set; }
    }
}
