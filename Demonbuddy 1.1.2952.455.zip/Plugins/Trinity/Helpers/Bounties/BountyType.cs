﻿
namespace Trinity.Helpers.Bounties
{
    public enum BountyType
    {
        Invalid,
        Kill,
        Clear,
        Event
    }
}
