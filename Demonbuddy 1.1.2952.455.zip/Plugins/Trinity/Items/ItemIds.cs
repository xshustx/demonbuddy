﻿
namespace Trinity.Items
{
    class ItemIds
    {
        public const string HoradricCache = "HoradricCache";

    }
}
