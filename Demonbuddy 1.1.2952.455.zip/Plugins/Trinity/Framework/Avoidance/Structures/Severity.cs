﻿namespace Trinity.Framework.Avoidance.Structures
{
    public enum Severity
    {
        None = 0,
        Minor,
        Normal,
        Extreme,
    }
}