namespace Trinity.Framework.Avoidance.Structures
{
    public enum MovementType
    {
        None = 0,
        Rotation,
        Traverse,
        Follow
    }
}
