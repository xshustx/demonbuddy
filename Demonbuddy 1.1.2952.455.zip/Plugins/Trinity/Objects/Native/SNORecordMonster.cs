﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Runtime.InteropServices;
//using System.Text;
//using System.Threading.Tasks;

//namespace Trinity.Objects.Native
//{
//    public struct SNORecordMonster
//    {
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 12)]
//      private byte[] _206A‍‫‏‭⁬⁫⁯‍‏‬⁭⁭⁯‏‍⁬‌‏‎‎‍⁬‭⁯‌‬‫⁭⁪‏‭‪⁪⁬‎​⁮‪⁮‮;
//      public int _200E‌⁯⁪​⁫⁫⁮‪‌‬‎​‪‏⁪‌⁫‮‬‌‮​‏‬‍‍‭‏​‭⁬‍⁪‍​⁯‪‌⁯‮;
//      public int _206D‎‮⁭‪⁮‏⁭‫‌‬‪‫⁯‪⁫⁫‫‍‏⁯‏⁯‍‬‎⁪‪‬⁮⁮⁫‌⁫‌‪‫⁯⁯‮‮;
//      public int _206E‫​‭‫‌⁯⁬‍‮‫⁯‫⁪⁫⁪‏‫‭⁯⁬​⁪‫‎‌⁮⁫⁮‬‭‭​⁬‍⁭⁬‪⁪‫‮;
//      public int _202E‬‎⁯‏⁯‪⁯‮‌‮⁯‫‍⁮⁬‌‪‬‬⁪‬‏‮‭⁫‮⁫⁭‭​‮‎⁮‎‪‎⁮⁭‌‮;
//      public int _202A‪‬‮⁯‮‍⁫‮​⁮⁬‪‎⁮‭⁮‮​‬⁪‌⁭​‌⁮‎⁫⁫‪‪⁬‮‭‎⁬⁭⁫⁭⁬‮;
//      public int _206F‏‎⁫⁭‫⁬‎‎⁮‬‌‭‌‌⁪⁫‎‭‪⁪‫‎⁫‪‭⁫⁮‏​‭‪‬‫‏‮‮⁬​‪‮;
//      public float _202B⁫‮‍‏‮⁬⁫⁫‬⁮‪‎‏‍‪‬‮‪‎‎⁯‪⁭‍‪⁫‫⁮‮⁭⁭⁫⁭‌‬⁬‏‎‎‮;
//      public float _200B‌​⁭​‬‍‫‮‭‫‍‏​‌‍‮‭⁮‪⁪‬‬⁫​⁮⁬​⁭‍⁭‮‌‮‌‮⁮‫⁭⁮‮;
//      public float _202D‪⁮‫‏⁮⁭⁫‭‫‎⁬⁬‬‎‎‭‌⁪⁬⁮‪‌​⁪⁬⁭​‎‪‏⁬⁬‮⁫⁭‪‍⁭⁪‮;
//      public float _206A‬​‎‪‫‍⁭​⁮⁬‍⁪‫‫‏‬⁭‫‏⁮⁪‭‍⁮‫‏‫‭⁭‏‫⁫⁯‪‪‪‫⁫⁯‮;
//      public int _200E‬‮‍‫‪‪⁫‬⁪​⁯‮‪‬‭‍‬⁭​‫‬‮‫⁭‭​‭⁭‏‮‏‎‎‎‭⁬​‌‪‮;
//      public int _200E​‬‮⁭‪‬⁯⁬‪‏‍‎‫⁬‭⁬‫‬‌⁯‮⁯⁬⁮‭‮‮⁮⁭‬‮‍‪‪⁯⁮‏⁬‍‮;
//      public int _200D‏⁮‎‏‫​⁫⁬‪⁯‫⁪‎⁯​⁬‌⁫⁪⁪‪‏‫⁮​‪‪‌​⁭‌‪‌‭‪⁫⁫‍⁪‮;
//      public int _206E​⁪⁫⁯‍‫⁪‬‏‭‎‭⁮⁬‪‌‎‮⁬‏⁬⁮⁪‫‏⁬‫‪⁯‍‪‮‍⁫⁯‍‌⁭‮‮;
//      public int _200F​‪​​‪​‫‏‌‬‬⁪‪‌⁬‏‪‫‪⁮‎‍‫⁪‫‫‭⁪⁮⁪⁫⁭‎⁬⁬​⁪⁬‭‮;
//      public int _202D‭‬‮‌⁬‭‫‫‫‬⁫‫⁯⁯‮⁬‪⁭⁯​‫⁭⁪⁫‫‫‍‍‌‮⁯⁮‍‭‪‮‏​⁪‮;
//      public int _206E‪⁫⁪‬‮‬‎⁪⁬‎‭‍⁪‬‫‍⁫⁯​‎‬⁮‍‎⁪‮⁬⁯⁪⁯‌‮⁪⁬‍‍⁭‍‍‮;
//      public int _202B⁪‬​⁯​‪‬‏‭‬​⁭​‏‎⁭‮⁬‮⁬‌‌‮‮⁯‎‫‍‫‮⁯⁬⁭‍‭⁮‪⁭‮‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 157)]
//      public int[] _206C‍⁯‮‏‬​‫⁯⁭⁬​‎‭‫​⁪‭‌⁪⁬‎⁬⁭‮‮‏⁪⁭⁭‭⁬‍⁫‌⁫⁯⁬‬‏‮;
//      public int _206C⁭⁭‍⁭‮‪‎‭‍‎‌⁬⁪​⁫‮‪​⁯‭‮‌⁫‏‏‭⁯‬‍​‍‍‎​‮​‪‍⁫‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 48)]
//      public byte[] _202D⁬‬‏‫‎‮⁫​‬‍⁯‫‍⁬‫‪‍​‬‫​⁯⁭‫‍‮‍⁪‌⁬‮⁮​⁪‏⁮‌​‍‮;
//      public int _202C‏⁭‎​‫⁭‌​‬‪‬⁬​‏‎⁯‭‬‎‬‬‪⁪⁬⁪⁪‫‫⁫⁭‮⁭⁪​⁭⁮‎⁬‎‮;
//      public int _202E⁭‪‎‪‎​⁮‎‮‎​​‬‌‫‪‎‌‍‭⁭‫‮‭‎​⁫‍⁮‬⁬​‮‍‫⁬‬⁮‏‮;
//      public int _206A‬‏‍⁪‌‭‌⁫‫‪⁭⁮​⁫‭‭‍‮‬⁮⁯⁭⁭⁫‍⁬⁬‌⁫⁫‭⁯⁪⁬⁬‫⁬⁫‏‮;
//      public int _206E​‬​⁫⁭‎⁪⁬‪‭⁯‮​‮‪⁪‌‎‭⁫‪‎⁫​‭‭⁭‎⁫‌‪‍‭⁮​‭‭⁫⁫‮;
//      public int _202E⁪‬‮‌‫‏‫⁫⁫​‮‎‍⁮‫‪‎⁯‏‍⁬‌‪‭‪‍⁫‭​‫‬‮‬⁬⁯‍⁯⁮‏‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
//      public int[] _200E‭‮⁪‫⁯⁬‎‭⁭⁮‪‬⁮‎⁮⁭​⁯⁫⁬⁫⁬⁪‭‬‫⁭‌⁮⁮⁪‌⁬⁮⁭‪‭‪‏‮;
//      public int _206B‍⁯⁭‍​⁫⁭‍‮‌⁮⁬⁫⁪‎‬⁮⁬‫⁯‬⁮‏‪⁭‏⁬⁯⁬‏⁫⁪‍‪‪‫⁮⁮‌‮;
//      public int _206C⁫⁫‌‌‏⁯⁭‮‫⁮‫⁪‌‭‮‍⁫⁪‎⁪‌‌⁯​‪‫⁮⁭‏⁮‭‪‏‎⁯⁬⁫‏‬‮;
//      public int _200B‫⁯‪​⁯‍‫⁭⁪‮⁯‎⁫‮‮‌‍‭⁫⁭⁬‌‌‬‏‮⁮⁫‭​‬‫‍‮⁮⁭⁬​‪‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
//      public int[] _202D⁬‏‌⁬‌‍‏⁮‪‌⁪⁬⁯⁬⁯‍⁮‎⁫⁬⁬‍‮‫‎⁭‪​‬⁭⁪‪‏‌⁯‬‏‫‮‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
//      public int[] _202E‬‍‎‪‍⁬‎‪⁪‬⁬⁯⁭⁫⁪‫‎‫‏‌⁬‬⁬‭​‭⁯⁮⁯‏‍‮⁫⁫‍‮​⁫‎‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
//      public int[] _206F‪‏‪‮‮⁫​​⁬​⁫‌​‌⁮​⁮‭‮‏⁪⁬‌‪‮⁪‭‌‮‮‬‍‪⁯⁬‬⁫‮⁯‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
//      public int[] _202A‮⁬‪‌⁪‏‫‪‬⁮‬‮‍‮‪‬​‮‌⁪⁭⁬‪⁪⁭‪⁮⁮‫‍‪‍‮‫‬⁫⁮‭‪‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
//      public int[] _202E‎‌‏‬‭⁭‬⁭‍‍‎‪⁮​‎‏‬‭⁮⁮⁮⁯‏‬‬‬‪​⁬‪‏⁭‬‫‬‌‫‪‌‮;
//      public int _200D‍‏‪‎⁪‬‮‪‏⁮​‍‍‎⁭‬⁯‫‫‪⁭​‭‍‮⁬‌‭‪‎‬⁫‌‫‎‌​⁬⁮‮;
//      public int _200C⁯⁮‮⁯‫⁯‪⁮⁭⁮⁪⁪‌⁮‍⁭‬‌‍⁫⁭‍⁮‏⁬‌​⁮‭‎⁬‬​⁭⁮‎‬‍⁬‮;
//      public int _200B⁬⁯⁮‍‭‍‌⁫‎‌‏‭‫‌‫‬⁪‮‮‮⁯⁪⁯‎‫​‍‫‪⁯‍‍⁬‪​⁮‎‭‫‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 44)]
//      public int[] _202B⁪⁫​⁬⁬⁫⁯⁭‭⁬‭‪‏⁬⁫‍‮⁫‬‮‮⁪​⁯⁮‍‏‎⁯⁭‭‫⁫⁬‌⁮​‮‭‮;
//      public int _202C‪⁬‏‎‭‌​‏‌⁬‌‬‌‮⁫‍⁪​‬‍‎‬‭‏‎​‫‏⁭⁯‫‌‫‮​‫‫‮⁬‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
//      public int[] _202D⁭‏⁯⁫⁫⁭⁬⁪⁯⁪‍‪‮‭⁯‍⁪​‭‬‌‏⁬‌⁫⁪‎‍⁪‍⁬‍‪⁫⁪⁫⁫⁬‎‮;
//      [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
//      public byte[] _200F‭‬⁫⁫‌⁯⁬‍‍‍‫‌⁬‪⁬⁮‭‌⁯‌⁯⁬⁭⁬⁬‌⁬⁫‍‍⁬​‮‎⁭‏‬​⁪‮;
//    }
//}

