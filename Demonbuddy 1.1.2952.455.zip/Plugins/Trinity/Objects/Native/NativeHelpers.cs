﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Zeta.Game;
using Zeta.Game.Internals;

namespace Trinity.Objects.Native
{
    public static class NativeHelpers
    {
        #region XZJV's Zeta API

        private static readonly Type ZetaDiaType = typeof(ZetaDia);

        private static Func<ACDManager> _getActorCommonData;

        public static ACDManager GetActorCommonData()
        {
            if (_getActorCommonData == null)
            {
                _getActorCommonData = GetStaticAccessor<ACDManager>(ZetaDiaType, "ActorCommonData");
            }
            return _getActorCommonData();
        }

        private static Func<RActorManager> _getRActors;

        public static RActorManager GetRActors()
        {
            if (_getRActors == null)
            {
                _getRActors = GetStaticAccessor<RActorManager>(ZetaDiaType, "RActors");
            }
            return _getRActors();
        }

        static readonly Dictionary<Type, Func<int, IntPtr>> GetRecordPtrMethods = new Dictionary<Type, Func<int, IntPtr>>();

        /// <summary>
        /// Call private method GetRecordPtr on SNOTable instance
        /// GetRecordPtr() finds a record pointer in a table for given value
        /// e.g. var testPtr = ZetaDia.SNO[ClientSNOTable.ActorInfo].GetRecordPtr(ZetaDia.Me.ActorSnoId);
        /// </summary>
        public static IntPtr GetRecordPtr(this SNOTable table, int id)
        {
            var type = typeof(SNOTable);
            Func<int, IntPtr> expr;

            if (!GetRecordPtrMethods.TryGetValue(type, out expr))
            {
                // Get all delcared private methods
                var methods = type.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly);

                // GetRecordPtr is obfusticated with no name so find a method with the right pattern of args
                var method = methods.FirstOrDefault(m => m.ReturnType == typeof(IntPtr));

                if (method == null)
                    throw new NullReferenceException("GetRecordPtr MethodInfo cannot be null");

                // Define that expression will take an Int argument
                var parameterExpr = Expression.Parameter(typeof(int), "input");

                // Define instance that MethodInfo will be executed against.
                var instanceExpr = Expression.Constant(table);

                // Formalize instance, method and arguments.
                var methodCallExpr = Expression.Call(instanceExpr, method, parameterExpr);

                expr = Expression.Lambda<Func<int, IntPtr>>(methodCallExpr, parameterExpr).Compile();

                GetRecordPtrMethods.Add(type, expr);
            }

            return expr != null ? expr(id) : new IntPtr(-1);
        }

        static readonly Dictionary<Type, Action<IntPtr>> PurgeSNORecordPtrMethods = new Dictionary<Type, Action<IntPtr>>();

        /// <summary>
        /// Call private method GetRecordPtr on SNOTable instance.
        /// Apparently bad things ensue if you don't purge the record after using it
        /// </summary>
        public static void PurgeRecordPtr(this SNOTable table, IntPtr ptr)
        {
            var type = typeof(SNOTable);
            Action<IntPtr> expr;

            if (!PurgeSNORecordPtrMethods.TryGetValue(type, out expr))
            {
                // Get all delcared private methods
                var methods = type.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly);

                // PurgeSNORecord is obfusticated with no name so find a method with the right pattern of args
                var method = methods.FirstOrDefault(m => m.ReturnType == typeof(void));

                if (method == null)
                    throw new NullReferenceException("GetRecordPtr MethodInfo cannot be null");

                // Define that expression will take an Int argument
                var parameterExpr = Expression.Parameter(typeof(IntPtr), "input");

                // Define instance that MethodInfo will be executed against.
                var instanceExpr = Expression.Constant(table);

                // Formalize instance, method and arguments.
                var methodCallExpr = Expression.Call(instanceExpr, method, parameterExpr);

                expr = Expression.Lambda<Action<IntPtr>>(methodCallExpr, parameterExpr).Compile();

                PurgeSNORecordPtrMethods.Add(type, expr);
            }

            if (expr != null)
                expr(ptr);
        }

        /// <summary>
        /// Gets a static field or property
        /// </summary>
        /// <typeparam name="T">the return type of the member</typeparam>
        /// <param name="containingClassType">type of the containing class</param>
        /// <param name="memberName">the name of the member</param>
        /// <returns>function to access the member</returns>
        public static Func<T> GetStaticAccessor<T>(Type containingClassType, string memberName)
        {
            var param = Expression.Parameter(containingClassType, "arg");
            var member = StaticPropertyOrField(containingClassType, memberName);
            var lambda = Expression.Lambda(member);
            return (Func<T>)lambda.Compile();
        }

        /// <summary>
        /// Gets an instanced field or property
        /// </summary>
        /// <typeparam name="T">class containing the member</typeparam>
        /// <typeparam name="TR">the return type of the member</typeparam>
        /// <param name="memberName">the name of the member</param>
        /// <returns>function to access the member</returns>
        public static Func<T, TR> GetInstanceAccessor<T, TR>(string memberName)
        {
            var type = typeof(T);
            var param = Expression.Parameter(type, "arg");
            var member = Expression.PropertyOrField(param, memberName);
            var lambda = Expression.Lambda(typeof(Func<T, TR>), member, param);
            return (Func<T, TR>)lambda.Compile();
        }

        public static IntPtr GetMonsterInfoPointer(int monsterSNO)
        {
            return GetRecordPtr((SNOTable)MonsterSNOTable, monsterSNO);
        }

        public static IntPtr GetActorInfoPointer(int actorSNO)
        {
            return GetRecordPtr((SNOTable)ActorSNOTable, actorSNO);
        }

        internal static SNOTable ActorSNOTable
        {
            get { return ZetaDia.SNO[ClientSNOTable.Actor]; }
        }

        internal static SNOTable MonsterSNOTable
        {
            get { return ZetaDia.SNO[ClientSNOTable.Monster]; }
        }

        #endregion        

        #region Reflection Utiltiies

        public static Type GetEnumerableType(Type type)
        {
            foreach (Type intType in type.GetInterfaces())
            {
                if (intType.IsGenericType && intType.GetGenericTypeDefinition() == typeof(IEnumerable<>))
                {
                    return intType.GetGenericArguments()[0];
                }
            }
            return null;
        }

        /// <summary>
        /// Create a MemberExpression for a static Property or Field
        /// </summary>
        public static MemberExpression StaticPropertyOrField(Type type, string propertyOrFieldName)
        {
            if (type == null)
                throw new ArgumentNullException("type");

            PropertyInfo property = type.GetProperty(propertyOrFieldName, BindingFlags.FlattenHierarchy | BindingFlags.Public | BindingFlags.IgnoreCase | BindingFlags.Static);
            if (property != null)
            {
                return Expression.Property(null, property);
            }
            FieldInfo field = type.GetField(propertyOrFieldName, BindingFlags.FlattenHierarchy | BindingFlags.Public | BindingFlags.IgnoreCase | BindingFlags.Static);
            if (field == null)
            {
                property = type.GetProperty(propertyOrFieldName, BindingFlags.FlattenHierarchy | BindingFlags.NonPublic | BindingFlags.IgnoreCase | BindingFlags.Static);
                if (property != null)
                {
                    return Expression.Property(null, property);
                }
                field = type.GetField(propertyOrFieldName, BindingFlags.FlattenHierarchy | BindingFlags.NonPublic | BindingFlags.IgnoreCase | BindingFlags.Static);
                if (field == null)
                {
                    throw new ArgumentException(String.Format("{0} NotAMemberOfType {1}", propertyOrFieldName, type));
                }
            }
            return Expression.Field(null, field);
        }

        #endregion


    }
}
