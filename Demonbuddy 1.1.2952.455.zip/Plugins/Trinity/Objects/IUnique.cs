﻿namespace Trinity.Objects
{
    public interface IUnique
    {
        int Id { get; } 
    }
}
