﻿
namespace Trinity.Cache
{
    public enum TrinityItemQuality
    {
        Unknown = -1,
        Common = 0,
        Magic = 1,
        Rare = 2,
        Legendary = 3, 
        Set = 4
    }
}
