﻿
namespace Trinity.Notifications
{
    public enum ProwlNotificationPriority : sbyte
    {
        VeryLow = -2,
        Moderate = -1,
        Normal = 0,
        High = 1,
        Emergency = 2
    }
}
