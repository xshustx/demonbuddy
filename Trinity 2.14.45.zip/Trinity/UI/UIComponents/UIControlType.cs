﻿namespace Trinity.UIComponents
{
    public enum UIControlType
    {
        Label = 0,
        TextBox,
        ComboBox,
        Slider,
        Checkbox,
        FlagsCheckboxes,
        BoundComboBox,
        BoundComboSlider,
        BoundDualComboSlider
    }
}







