﻿// DateTimeInterval.cs by Charles Petzold, September 2009

namespace LineChartLib
{
    public enum DateTimeInterval
    {
        Second,
        Minute,
        Hour,
        Day,
        Month,
        Year
    }
}
