﻿// ItemPointCollection.cs by Charles Petzold, September 2009
using System.Collections.ObjectModel;

namespace LineChartLib
{
    public class ItemPointCollection : ObservableCollection<ItemPoint>
    {
    }
}
