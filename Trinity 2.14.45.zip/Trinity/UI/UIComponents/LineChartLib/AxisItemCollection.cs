﻿// AxisItemCollection.cs by Charles Petzold, September 2009
using System;
using System.Collections.ObjectModel;

namespace LineChartLib
{
    public class AxisItemCollection : ObservableCollection<AxisItem>
    {
    }
}
