﻿using Buddy.Overlay.Controls;

namespace Trinity.UI.UIComponents.RadarCanvas
{
    class RadarOverlayControl : OverlayControl
    {
        //override onr
    }
}
