﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Media3D;
using System.Windows.Threading;
using Trinity.Objects;
using Trinity.UI.Overlays._3D;
using Trinity.UI.Overlays._3D.Perspective.Primitives;
using Trinity.UI.Overlays._3D.Perspective.Shapes;
using Trinity.UI.Overlays._3D._3DTools;
using Zeta.Bot;
using Zeta.Common;
using Logger = Trinity.Technicals.Logger;

namespace Trinity.UI.Overlays
{
    //[ContentProperty("Children")]
    public class Viewport3DRadar : Viewport3D //FrameworkElement
    {
        private readonly ConcurrentDictionary<int, ViewPort3DActor> _actors = new ConcurrentDictionary<int, ViewPort3DActor>();
        private readonly SolidColorBrush _blueBrush = new SolidColorBrush(Colors.Blue);
        private readonly HashSet<int> _currentRActorGuids = new HashSet<int>();
        private readonly ModelVisual3D _defaultLightingModel = new ModelVisual3D();
        private readonly Stopwatch _movementTimer = new Stopwatch();
        private readonly Timer _refreshTimer;
        private int _frame;
        private Point3D _lastCameraPosition;
        private Vector3 _lastMoveDelta;
        private Spherical3D _playerSphere;
        private Timer _renderTimer;
        private Viewport3D _viewport;
        private ScreenSpaceLines3D _wireframe;
        private ModelVisual3D BlueSphere = new ModelVisual3D();

        public Viewport3DRadar()
        {
            ClipToBounds = true;
            AllowDrop = false;
            IsHitTestVisible = false;
            SnapsToDevicePixels = false;
            VisualBitmapScalingMode = BitmapScalingMode.NearestNeighbor;

            CreateLighting();

            _refreshTimer = new Timer(250);
            _refreshTimer.Elapsed += TimerElapsed;
            _refreshTimer.Enabled = true;

            CompositionTarget.Rendering += CompositionTargetOnRendering;
        }

        public Point3D CenterPosition { get; set; }
        //private void InitializeCamera()
        //{
        //    //var camera = (_viewport.Camera as PerspectiveCamera);
        //    var camera = (Camera as PerspectiveCamera);
        //    //if (camera == null)
        //    //    return;

        //    camera.UpDirection = new Vector3D(0,0,1);
        //    camera.Position = new Point3D(111, 120, 110);
        //    //camera.LookDirection = new Vector3D(-9, -10, -9);
        //    camera.LookDirection = new Vector3D(-1,-1,-1);
        //    camera.NearPlaneDistance = 0;
        //    camera.FarPlaneDistance = 0;
        //    camera.FieldOfView = 20;
        //}

        private void SetNotAnimating(object sender, EventArgs eventArgs)
        {
            _isAnimating = false;
        }

        private void CompositionTargetOnRendering(object sender, EventArgs eventArgs)
        {
            if (BotMain.IsPausedForStateExecution)
                return;

            SmoothedCameraMove();
        }

        private static Point3D GetCamPosition(Vector3 centerPos, ViewPortModel model)
        {
            return new Point3D(centerPos.X + model.CameraPositionX, centerPos.Y + model.CameraPositionY, centerPos.Z + model.CameraPositionZ);
        }

        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(Refresh));
        }

        private void CreateLighting()
        {
            var light1 = new DirectionalLight(Colors.White, new Vector3D(0.0, -1.0, 1.0));
            var light2 = new DirectionalLight(Colors.White, new Vector3D(-1.0, -1.0, -1.0));
            var light3 = new DirectionalLight(Colors.White, new Vector3D(1.0, -1.0, -1.0));
            var light4 = new DirectionalLight(Colors.White, new Vector3D(0.0, 1.0, 0.0));
            light1.Freeze();
            light2.Freeze();
            light3.Freeze();
            light4.Freeze();
            var mg = new Model3DGroup();
            mg.Children.Add(light1);
            mg.Children.Add(light2);
            mg.Children.Add(light3);
            mg.Children.Add(light4);
            _defaultLightingModel.Content = mg;
            Children.Add(_defaultLightingModel);
        }

        protected override Size MeasureOverride(Size availableSize)
        {
            if (double.IsPositiveInfinity(availableSize.Width) || double.IsPositiveInfinity(availableSize.Height))
            {
                return Size.Empty;
            }
            return availableSize;
        }

        private void Refresh()
        {
            try
            {
                var objects = ViewPortModel.Instance.Objects.ToList();

                _currentRActorGuids.Clear();

                foreach (var updatedWorldActor in objects)
                {
                    if (updatedWorldActor.Distance >= 30f)
                        continue;

                    ViewPort3DActor actor;
                    if (!_actors.TryGetValue(updatedWorldActor.RActorGuid, out actor))
                    {
                        Dispatcher.Invoke(DispatcherPriority.Normal, new Action(async () => await CreateVisual(updatedWorldActor)));
                    }
                    else
                    {
                        actor.Update(updatedWorldActor);
                    }

                    if (!_currentRActorGuids.Contains(updatedWorldActor.RActorGuid))
                        _currentRActorGuids.Add(updatedWorldActor.RActorGuid);
                }

                foreach (var child in Children.ToList())
                {
                    var visual = child as GeometryElement3D;
                    if (visual == null)
                        continue;

                    if (!_currentRActorGuids.Contains(visual.Id))
                    {
                        Logger.Log("Removing {0}", visual.Id);
                        ViewPort3DActor removedActor;
                        _actors.TryRemove(visual.Id, out removedActor);
                        Children.Remove(child);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception in Viewport3DRadar.Refresh(). {0} {1} {2}", ex.Message, ex.InnerException, ex);
            }
        }

        private async Task<bool> CreateVisual(IActor updatedWorldActor)
        {
            ViewPort3DActor actor;
            var visual = CreateActorVisual(updatedWorldActor);
            visual.Id = updatedWorldActor.RActorGuid;
            visual.DefaultTextureMapping = false;
            visual.Freeze();
            actor = new ViewPort3DActor(updatedWorldActor, null, visual);

            _actors.TryAdd(updatedWorldActor.RActorGuid, actor);

            //_viewport.Children.Add(actor.Visual);
            Children.Add(actor.Visual);
            Logger.Log("Created model for {0}, ({1})", updatedWorldActor.InternalName, updatedWorldActor.RActorGuid);
            return true;
        }

        private GeometryElement3D CreateActorVisual(IActor actor)
        {
            var sphere = new Spherical3D();
            sphere.Material = GetSurfaceMaterial();
            return sphere;
        }

        public MaterialGroup GetSurfaceMaterial()
        {
            var materialGroup = new MaterialGroup();
            var emmMat = new EmissiveMaterial(_blueBrush);
            //emmMat.Freeze();
            var interactiveMaterial = new DiffuseMaterial();
            //interactiveMaterial.Freeze();
            //interactiveMaterial.SetValue(InteractiveVisual3D.IsInteractiveMaterialProperty, true);
            //materialGroup.Children.Add(interactiveMaterial);
            materialGroup.Children.Add(emmMat);
            materialGroup.Children.Add(new DiffuseMaterial());
            //var specMat = new SpecularMaterial(new SolidColorBrush(Colors.White), 30);
            //materialGroup.Children.Add(specMat);
            materialGroup.Freeze();
            return materialGroup;
        }

        #region Interpolated Movement

        private Point3DAnimation _cameraPositionAnimation;
        private Vector3 _lastPosition;
        private DateTime _lastFrameTime = DateTime.UtcNow;
        private Vector3 _lastPositionDelta;
        private double _lastTimeDelta;
        private DateTime _lastSmoothMoved;
        private Vector3 _lastSmoothMovePosition;
        private bool _isAnimating;

        private void SmoothedCameraMove()
        {
            var model = ViewPortModel.Instance;
            var position = model.PlayerPosition;
            var positionDelta = position - _lastPosition;
            var timeDelta = _movementTimer.Elapsed.TotalMilliseconds;
            var MoveFrameInterval = 40;

            //var cam = (PerspectiveCamera)Camera;
            //cam.Position = GetCamPosition(position, model);

            if (!_isAnimating)
            {
                var newCameraPos = GetCamPosition(position, model);
                var cam = (PerspectiveCamera) Camera;
                if (_cameraPositionAnimation != null)
                {
                    _cameraPositionAnimation.Completed -= SetNotAnimating;
                }
                _cameraPositionAnimation = new Point3DAnimation(newCameraPos, TimeSpan.FromMilliseconds(MoveFrameInterval));
                //_cameraPositionAnimation.EasingFunction = new BackEase();
                _cameraPositionAnimation.Completed += SetNotAnimating;
                _isAnimating = true;
                cam.ApplyAnimationClock(ProjectionCamera.PositionProperty, _cameraPositionAnimation.CreateClock());
                _lastSmoothMovePosition = position;
                _lastSmoothMoved = DateTime.UtcNow;
            }

            Logger.Log("SinceLastRender={0}ms TimeSinceMove={1} Center={2}",
                DateTime.UtcNow.Subtract(_lastFrameTime).TotalMilliseconds,
                DateTime.UtcNow.Subtract(_lastSmoothMoved).TotalMilliseconds,
                position);

            _lastTimeDelta = timeDelta;
            _lastPositionDelta = positionDelta;
            _lastPosition = position;
            _lastFrameTime = DateTime.UtcNow;
        }

        #endregion
    }
}