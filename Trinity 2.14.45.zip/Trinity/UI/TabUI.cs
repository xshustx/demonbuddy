﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Trinity.Cache;
using TrinityCoroutines;
using TrinityCoroutines.Resources;
using Trinity.DbProvider;
using Trinity.Helpers;
using Trinity.ItemRules;
using Trinity.Items;
using Trinity.UI.RadarUI;
using Trinity.UI.UIComponents;
using Zeta.Bot;
using Zeta.Bot.Navigation;
using Zeta.Common;
using Zeta.Game;
using Zeta.Game.Internals;
using Zeta.Game.Internals.Actors;
using Logger = Trinity.Technicals.Logger;
using TrinityItemQuality = Trinity.Config.Combat.TrinityItemQuality;
using UIElement = Zeta.Game.Internals.UIElement;

namespace Trinity.UI
{
    internal class TabUi
    {
        private static UniformGrid _tabGrid;
        private static TabItem _tabItem;
        private static DateTime LastStartedConvert = DateTime.UtcNow;

        internal static void InstallTab()
        {
            Application.Current.Dispatcher.Invoke(
                () =>
                {
                    var mainWindow = Application.Current.MainWindow;

                    _tabGrid = new UniformGrid
                    {
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        VerticalAlignment = VerticalAlignment.Top,
                        Columns = 4,
                        MaxHeight = 180,
                        Margin = new Thickness(0,0,16,0)
                    };

                    CreateStretchyGroup(string.Empty, new List<Control>
                    {
                        CreateMajorButton("Configure", ShowMainTrinityUIEventHandler),
                        CreateMajorButton("Open Visualizer", OpenRadarButtonHandler)
                    });

                    CreateGroup("Items", new List<Control>
                    {
                        CreateButton("Sort Backpack", SortBackEventHandler),
                        CreateButton("Sort Stash", SortStashEventHandler),
                        CreateButton("Clean Stash", CleanStashEventHandler),
                        CreateButton("Convert to Magic", btnClick_ConvertToBlue),
                        CreateButton("Convert to Common", btnClick_ConvertToCommon),
                        CreateButton("Convert to Rare", btnClick_ConvertToRare),
                    });

                    CreateGroup("Debugging", new List<Control>
                    {                        
                        CreateButton("Find New ActorIds", GetNewActorSNOsEventHandler),                        
                        CreateButton("Log Invalid Items", LogInvalidHandler),
                        CreateButton("> Gizmo Test", StartGizmoTestHandler),
                        CreateButton("> Unit Test", StartUnitTestHandler),
                        //CreateButton("> Buff Test", StartBuffTestHandler),
                        CreateButton("> Stop Tests", StopTestHandler),
                        CreateButton("ItemList Check", btnClick_TestItemList),
                    });

                    CreateGroup("Tools", new List<Control>
                    {
                        CreateButton("Dump My Build", DumpBuildEventHandler),
                        CreateButton("Drop Legendaries", DropLegendariesEventHandler),
                        CreateButton("Log Run Time", btnClick_LogRunTime),
                        CreateButton("Open Log File", OpenLogFileHandler),                        
                    });

                    //CreateButton("Scan UIElement", btnClick_ScanUIElement)
                    //CreateButton("Reload Item Rules", ReloadItemRulesEventHandler);                    
                    //CreateButton("Show Cache", ShowCacheWindowEventHandler);
                    //CreateButton("Open Radar", OpenRadarButtonHandler);
                    //CreateButton("Start Progression", StartProgressionTestHandler);             
                    //CreateButton("Stop Progression", StopProgressionTestHandler);                                    
                    //CreateButton("Cache Test", CacheTestCacheEventHandler);                    
                    //CreateButton("Special Test", btnClick_SpecialTestHandler);
                    //CreateButton("1000 Rare => Magic", btnClick_MassConvertRareToMagic);
                    //CreateButton("Move to Stash", btnClick_MoveToStash);
                    //CreateButton("Move to Cube", btnClick_MoveToCube);
                    //CreateButton("Rares => Legendary", btnClick_UpgradeRares);
                    //CreateButton("Test1", btnClick_Test1);
                    //CreateButton("Test2", btnClick_HijackTest);

                    _tabItem = new TabItem
                    {
                        Header = "Trinity",
                        Content = _tabGrid                        
                    };

                    var tabs = mainWindow.FindName("tabControlMain") as TabControl;
                    if (tabs == null)
                        return;

                    tabs.Items.Add(_tabItem);
                }
                );
        }

        /**************
         * 
         * WARNING
         * 
         * ALWAYS surround your RoutedEventHandlers in try/catch. Failure to do so will result in Demonbuddy CRASHING if an exception is thrown.
         * 
         * WARNING
         *  
         *************/
       
        private static void OpenRadarButtonHandler(object sender, RoutedEventArgs e)
        {
            try
            {
                var dataContext = VisualizerViewModel.Instance;

                VisualizerViewModel.Window = UILoader.CreateNonModalWindow(
                    "Visualizer\\Visualizer.xaml",
                    "Radar Visualizer",
                    dataContext,
                    dataContext.WindowWidth,
                    dataContext.WindowHeight
                    );

                VisualizerViewModel.Window.Show();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Opening Radar Window:" + ex);
            }
        }

        private static void btnClick_LogRunTime(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Bot {0} has been running for {1} hours {2} minutes and {3} seconds", ZetaDia.PlayerData.HeroName, GameStats.Instance.RunTime.Hours, GameStats.Instance.RunTime.Minutes, GameStats.Instance.RunTime.Seconds);
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception {0}", ex);
            }
        }

        private static void btnClick_TestItemList(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                using (new MemoryHelper())
                {
                    DebugUtil.ItemListTest();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception {0}", ex);
            }
        }

        private static void LogInvalidHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                DebugUtil.LogInvalidItems();
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception {0}", ex);
            }
        }

        private static void CacheTestCacheEventHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Finished Cache Test");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception {0}", ex);
            }
        }

        private static void StartProgressionTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {                
                //RiftProgression.ThreadStart();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Starting Rift Progression : " + ex);
            }
        }

        private static void StartUnitTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                var unitAtts = new Dictionary<int, HashSet<ActorAttributeType>>();
                var unitLastDamage = new Dictionary<int, float>();

                if (!ZetaDia.IsInGame)
                    return;

                Worker.Start(() =>
                {
                    using (new MemoryHelper())
                    {
                        Func<DiaObject, bool> isValid = u => u != null && u.IsValid && u.CommonData != null && u.CommonData.IsValid && !u.CommonData.IsDisposed;

                        var testunits = ZetaDia.Actors.GetActorsOfType<DiaObject>(true).Where(u => isValid(u) && u.RActorId != ZetaDia.Me.RActorId).ToList();
                        //if (!testunits.Any())
                        //    return false;

                        //testunits = testunits.Where(u => u.ActorSnoId == 340319 || u.ActorSnoId == 325761 || u.ActorSnoId == 316389).ToList();
                       // testunits = testunits.Where(u => u.ActorSnoId == 4080).ToList();

                        var testunit = testunits.OrderBy(u => u.Distance).FirstOrDefault();
                        if (testunit == null || testunit.CommonData == null)
                        {
                            //return false;
                            testunit = ZetaDia.Me;
                        }

                        MonitorActors(testunit, unitAtts);
                    }
                    return false;
                });
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Starting LazyCache: " + ex);
            }
        }

        private static void OpenLogFileHandler(object sender, RoutedEventArgs e)
        {
            string logFile = "";
            try
            {
                string exePath = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

                int myPid = Process.GetCurrentProcess().Id;
                DateTime startTime = Process.GetCurrentProcess().StartTime;
                if (exePath != null)
                    logFile = Path.Combine(exePath, "Logs", myPid + " " + startTime.ToString("yyyy-MM-dd HH.mm") + ".txt");

                if (File.Exists(logFile))
                    Process.Start(logFile);
                else
                {
                    Logger.LogError("Unable to open log file {0} - file does not exist", logFile);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Error opening log file: {0} {1}", logFile, ex.Message);
            }
        }

        private static void StartBuffTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                var unitAtts = new Dictionary<int, HashSet<ActorAttributeType>>();
                var unitLastDamage = new Dictionary<int, float>();

                if (!ZetaDia.IsInGame)
                    return;

                Worker.Start(() =>
                {
                    using (new MemoryHelper())
                    {
                        Func<DiaObject, bool> isValid = u => u != null && u.IsValid && u.CommonData != null && u.CommonData.IsValid && !u.CommonData.IsDisposed;

                        if (!isValid(ZetaDia.Me))
                            return false;

                        //var buff = ZetaDia.Me.GetAllBuffs().FirstOrDefault();
                        //if (buff == null)
                        //    return false;

                        //int remainingTime;
                        //Logger.Log("Remaining Time for {0} is {1}", (SNOPower)buff.SNOId, buff.TryGetRemainingTime(out remainingTime) ? remainingTime.ToString() : "NA");

                    }
                    return false;
                });
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Starting LazyCache: " + ex);
            }
        }



        private static void StartGizmoTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                var unitAtts = new Dictionary<int, HashSet<ActorAttributeType>>();
                var unitLastDamage = new Dictionary<int, float>();

                if (!ZetaDia.IsInGame)
                    return;

                Worker.Start(() =>
                {
                    using (new MemoryHelper())
                    {
                        Func<DiaObject, bool> isValid = u => u != null && u.IsValid && u.CommonData != null && u.CommonData.IsValid && !u.CommonData.IsDisposed;

                        var testunits = ZetaDia.Actors.GetActorsOfType<DiaGizmo>(true).Where(u => isValid(u) && u.RActorId != ZetaDia.Me.RActorId).ToList();

                        var testunit = testunits.OrderBy(u => u.Distance).FirstOrDefault();
                        if (testunit == null || testunit.CommonData == null)
                        {
                            return false;
                        }

                        MonitorActors(testunit, unitAtts);
                    }
                    return false;
                });
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Starting LazyCache: " + ex);
            }
        }

        private static void MonitorActors(DiaObject testunit, Dictionary<int, HashSet<ActorAttributeType>> unitAtts)
        {
            var existingAtts = unitAtts.GetOrCreateValue(testunit.ACDId, new HashSet<ActorAttributeType>());
            var atts = Enum.GetValues(typeof (ActorAttributeType)).Cast<ActorAttributeType>().ToList();
            var annId = ZetaDia.Me.CommonData.AnnId;
            var acdId = ZetaDia.Me.ACDId;

            //var root = ZetaDia.Me.CommonData.GetAttribute<int>(ActorAttributeType.RootTotalTicks);
            //Logger.Log("Root Ticks {0}", root);

            //[Trinity 2.14.34] Unit FallenGrunt_A-69336 has MonsterAffix_IllusionistCast (PowerBuff0VisualEffectNone)

            foreach (var att in atts)
            {
                try
                {
                    var attiResult = testunit.CommonData.GetAttribute<int>(att);
                    var attfResult = testunit.CommonData.GetAttribute<float>(att);
                    var hasValue = attiResult > 0 || !float.IsNaN(attfResult) && attfResult > 0;                
                    if (hasValue)
                    {
                        if (!existingAtts.Contains(att) || att.ToString().ToLower().Contains("time") || att.ToString().ToLower().Contains("tick"))
                        {
                            Logger.Log("Unit {0} ({4}) has gained {1} (i:{2} f:{3:00.00000})", testunit.Name, att.ToString(), attiResult, attfResult, testunit.ActorSnoId);
                            existingAtts.Add(att);
                        }
                    }
                    else
                    {
                       
                        //var annIdResult = testunit.CommonData.GetAttribute<int>((annId << 12) + ((int)att & 0xFFF));
                        //var acdIdResult = testunit.CommonData.GetAttribute<int>((acdId << 12) + ((int)att & 0xFFF));
                        //if (annIdResult > 0 || acdIdResult > 0)
                        //{
                        //    Logger.Log("Unit {0} ({4}) has ACD/ANN ATTR {1} (acd{2} ann:{3})", testunit.Name, att.ToString(), annIdResult, acdIdResult, testunit.ActorSnoId);
                        //}

                        if (existingAtts.Contains(att))
                        {
                            Logger.Log("Unit {0} ({4}) has lost {1} (i:{2} f:{3:00.00000})", testunit.Name, att.ToString(), attiResult, attfResult, testunit.ActorSnoId);
                            existingAtts.Remove(att);
                        }
                    }
                }
                catch (Exception)
                {
                }
            }

            var allpowers = Enum.GetValues(typeof (SNOPower)).Cast<SNOPower>().ToList();
            var allAttributes = Enum.GetValues(typeof (ActorAttributeType)).Cast<ActorAttributeType>().ToList();
            var allBuffAttributes = allAttributes.Where(a => a.ToString().Contains("Power")).ToList();

            var checkpowers = new HashSet<SNOPower>
            {
                SNOPower.MonsterAffix_ReflectsDamage,
                SNOPower.MonsterAffix_ReflectsDamageCast,
                SNOPower.Monk_ExplodingPalm
            };

            foreach (var power in allpowers)
            {
                foreach (var buffattr in allBuffAttributes)
                {
                    try
                    {
                        if (testunit.CommonData.GetAttribute<int>(((int) power << 12) + ((int) buffattr & 0xFFF)) == 1)
                        {
                            Logger.Log("Unit {0} has {1} ({2})", testunit.Name, power, buffattr);
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            }

            var allTimeAttributes = allAttributes.Where(a => a.ToString().ToLower().Contains("time")|| a.ToString().ToLower().Contains("tick")).ToList();

            foreach (var power in allpowers)
            {
                foreach (var timeAttr in allTimeAttributes)
                {
                    try
                    {
                        var result = testunit.CommonData.GetAttribute<int>((int)timeAttr & ((1 << 12) - 1) | ((int)power << 12));
                        if (result > 1)
                        {
                            Logger.Log("Unit {0} has {1} ({2}) Value={3}", testunit.Name, power, timeAttr, result);
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
            }


            //var List<SNOPower> testPowers = new List<SNOPower>
            //{
            //    SNOPower.None
            //};

            //foreach (var timeAttr in allTimeAttributes)
            //{
            //    try
            //    {
            //        var result = testunit.CommonData.GetAttribute<int>((int)ActorAttributeType.PowerCooldown & ((1 << 12) - 1) | ((int)power << 12));
            //        if (result > 0)
            //        {
            //            Logger.Log("Unit {0} has {1} ({2}) Value={3}", testunit.Name, power, timeAttr, result);
            //        }
            //    }
            //    catch (Exception)
            //    {
            //    }
            //}

            //Logger.Log("),"testunit.CommonData.GetAttribute<int>((SNOPower.None << 12) + ((int)ActorAttributeType.None & 0xFFF)));


        }

        private static void StopTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Worker.Stop();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Starting LazyCache: " + ex);
            }
        }

        private static void StopProgressionTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                //RiftProgression.ThreadStop();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Starting LazyCache: " + ex);
            }
        }

        //private static void StartProgressionAutomatedHandler(object sender, RoutedEventArgs routedEventArgs)
        //{
        //    try
        //    {
        //        RiftProgression.StartAutomated();
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogError("Error Starting LazyCache: " + ex);
        //    }
        //}


        private static void btnClick_SpecialTestHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting");

                // A1 Open World Stash Location
                var stashlocation = new Vector3(388.16f, 509.63f, 23.94531f);

                CoroutineHelper.RunCoroutine(() => Navigator.MoveTo(TownRun.StashLocation));

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_MoveToStash(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting");

                CoroutineHelper.RunCoroutine(() => Navigator.MoveTo(Town.Locations.Stash));

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_MoveToCube(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting");

                CoroutineHelper.RunCoroutine(() => Navigator.MoveTo(Town.Locations.KanaisCube));

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_UpgradeRares(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting");

                CoroutineHelper.RunCoroutine(() => CubeRaresToLegendary.Execute());

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_BuyVendorBlues(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting");

                CoroutineHelper.RunCoroutine(() => BuyItemsFromVendor.Execute(ItemQualityColor.Yellow),
                    ret => BuyItemsFromVendor.CanRun(ItemQualityColor.Yellow));

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_HijackTest(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("HijackTest Started");

                CoroutineHelper.ForceRunCoroutine(() => CubeRaresToLegendary.Execute(), result => !CubeRaresToLegendary.CanRun());

                Logger.Log("HijackTest Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_Test1(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting");

                using (ZetaDia.Memory.AcquireFrame())
                {
                    ZetaDia.Actors.Update();

                    foreach (var item in ZetaDia.Me.Inventory.Backpack)
                    {
                        var stackHi = item.GetAttribute<int>(ActorAttributeType.ItemStackQuantityHi);
                        var stackLo = item.GetAttribute<int>(ActorAttributeType.ItemStackQuantityLo);

                        Logger.Log("Item: {0} {1} ItemStackQuantity={2} StackHi={3} StackLo={4}",
                            item.Name, item.ACDId, item.ItemStackQuantity, stackHi, stackLo);
                    }
                }

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_ConvertToBlue(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting Conversion of Backpack VeiledCrystals to Magic Dust.");

                if (Trinity.Settings.Loot.Pickup.MiscItemQuality > TrinityItemQuality.Common)
                {
                    Logger.LogError("Aborting - Dangerous to pull craftin items to backpack when MiscItemQuality setting is set above common");
                    return;
                }

                var result = ConvertMaterials(new [] { InventoryItemType.VeiledCrystal, InventoryItemType.ReusableParts }, InventoryItemType.ArcaneDust);

                Logger.Log("Finished Result={0}", result);
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static bool ConvertMaterials(InventoryItemType[] fromMaterials, InventoryItemType to)
        {
            var conversions = 0;
            var working = false;
            var startTime = DateTime.UtcNow;

            foreach (var fromMaterial in fromMaterials)
            {
                if (UIElements.TransmuteItemsDialog.IsVisible && TrinityCoroutines.ConvertMaterials.CanRun(fromMaterial, to))
                {
                    LastStartedConvert = DateTime.UtcNow;
                    CoroutineHelper.RunCoroutine(() => TrinityCoroutines.ConvertMaterials.Execute(fromMaterial, to), result =>
                    {
                        var r = !TrinityCoroutines.ConvertMaterials.CanRun(fromMaterial, to) || CheckConvertTimeout() || !result;
                        working = !r;
                        return r;

                    }, 50, () => working = false);                    
                    conversions++;
                }
                while (working)
                {
                    if (DateTime.UtcNow.Subtract(startTime).TotalSeconds > 30)
                    {
                        Logger.LogError("ConvertMaterials timed out");
                        break;
                    }
                    Thread.Sleep(500);
                }
            }

            return conversions > 0;
        }

        public static bool CheckConvertTimeout()
        {
            if (DateTime.UtcNow.Subtract(LastStartedConvert).TotalSeconds > 20)
            {
                Logger.LogError("Timeout");
                return true;
            }
            return false;
        }

        private static void btnClick_ConvertToCommon(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting Conversion of Backpack VeiledCrystals to ReusableParts");

                if (Trinity.Settings.Loot.Pickup.MiscItemQuality > TrinityItemQuality.Common)
                {
                    Logger.LogError("Aborting - Too dangerous to put crafting items into backpack when MiscItemQuality setting is set above common");
                    return;
                }

                var result = ConvertMaterials(new[] { InventoryItemType.ArcaneDust, InventoryItemType.VeiledCrystal }, InventoryItemType.ReusableParts);

                Logger.Log("Finished Result={0}", result);
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_ConvertToRare(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting Conversion of Backpack VeiledCrystals to ReusableParts");

                if (Trinity.Settings.Loot.Pickup.MiscItemQuality > TrinityItemQuality.Common)
                {
                    Logger.LogError("Aborting - Too dangerous to put crafting items into backpack when MiscItemQuality setting is set above common");
                    return;
                }

                var result = ConvertMaterials(new[] { InventoryItemType.ArcaneDust, InventoryItemType.ReusableParts }, InventoryItemType.VeiledCrystal);

                Logger.Log("Finished Result={0}", result);
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void btnClick_MassConvertRareToMagic(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                Logger.Log("Starting Conversion of Backpack VeiledCrystals to ArcaneDust");

                if (Trinity.Settings.Loot.Pickup.MiscItemQuality > TrinityItemQuality.Common)
                {
                    Logger.LogError("Aborting - Too dangerous to put crafting items into backpack when MiscItemQuality setting is set above common");
                    return;
                }

                var from = InventoryItemType.VeiledCrystal;
                var to = InventoryItemType.ArcaneDust;

                if (!UIElements.TransmuteItemsDialog.IsVisible || !TrinityCoroutines.ConvertMaterials.CanRun(from, to))
                {
                    Logger.LogError("You need to have the cube window open and all the required materials in your backpack.");
                    return;
                }

                LastStartedConvert = DateTime.UtcNow;

                CoroutineHelper.RunCoroutine(() => TrinityCoroutines.ConvertMaterials.Execute(from, to), result => !TrinityCoroutines.ConvertMaterials.CanRun(from, to) || CheckConvertTimeout());

                Logger.Log("Finished");
            }
            catch (Exception ex)
            {
                Logger.LogError("Exception: " + ex);
            }
        }

        private static void ShowCacheWindowEventHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                CacheUI.CreateWindow();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error showing CacheUI:" + ex);
            }
        }

        private static void btnClick_ScanUIElement(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                //[1E8E8E20] Last clicked: 0x80E63C97B008F590, Name: Root.NormalLayer.vendor_dialog_mainPage.training_dialog
                //[1E94FCC0] Mouseover: 0x244BD04C84DF92F1, Name: Root.NormalLayer.vendor_dialog_mainPage

                using (new MemoryHelper())
                {
                    UIElement.FromHash(0x244BD04C84DF92F1).FindDecedentsWithText("jeweler");
                }

            }
            catch (Exception ex)
            {
                Logger.LogError("Error btnClick_ScanUIElement:" + ex);
            }
        }


        private static void ShowMainTrinityUIEventHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                var configWindow = UILoader.GetDisplayWindow();
                configWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error showing Configuration from TabUI:" + ex);
            }
        }

        private static void DumpBuildEventHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                DebugUtil.LogBuildAndItems();
            }
            catch (Exception ex)
            {
                Logger.LogError("DumpBuildEventHandler: " + ex);
            }
        }

        private static void GetNewActorSNOsEventHandler(object sender, RoutedEventArgs routedEventArgs)
        {
            try
            {
                DebugUtil.LogNewItems();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error logging new items:" + ex);
            }
        }

        private static void SortBackEventHandler(object sender, RoutedEventArgs e)
        {
            try
            {
                ItemSort.SortBackpack();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error sorting backpack:" + ex);
            }
        }

        private static void DropLegendariesEventHandler(object sender, RoutedEventArgs e)
        {
            try
            {
                using (new MemoryHelper())
                {
                    ZetaDia.Me.Inventory.Backpack.Where(i => i.ItemQualityLevel == ItemQuality.Legendary).ForEach(i => i.Drop());

                    if (BotMain.IsRunning && !BotMain.IsPausedForStateExecution)
                        BotMain.PauseFor(TimeSpan.FromSeconds(2));
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Error dropping legendaries:" + ex);
            }
        }

        private static void SortStashEventHandler(object sender, RoutedEventArgs e)
        {
            try
            {
                ItemSort.SortStash();
            }
            catch (Exception ex)
            {
                Logger.LogError("Error dropping legendaries:" + ex);
            }
        }

        private static void CleanStashEventHandler(object sender, RoutedEventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are you sure? This may remove and salvage/sell items from your stash! Permanently!", "Clean Stash Confirmation",
                    MessageBoxButton.OKCancel);

                if (result == MessageBoxResult.OK)
                {
                    CleanStash.RunCleanStash();
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Cleaning Stash:" + ex);
            }
        }

        private static void ReloadItemRulesEventHandler(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Trinity.StashRule == null)
                    Trinity.StashRule = new Interpreter();

                if (Trinity.StashRule != null)
                {
                    BotMain.PauseWhile(Trinity.StashRule.reloadFromUI);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Error Reloading Item Rules:" + ex);
            }
        }

        #region TabMethods

        internal static void RemoveTab()
        {
            Application.Current.Dispatcher.Invoke(
                () =>
                {
                    var mainWindow = Application.Current.MainWindow;
                    var tabs = mainWindow.FindName("tabControlMain") as TabControl;
                    if (tabs == null)
                        return;
                    tabs.Items.Remove(_tabItem);
                }
                );
        }

        private static Button CreateMajorButton(string buttonText, RoutedEventHandler clickHandler)
        {
            var button = new Button
            {
                //Width = 120,                
                Background = Brushes.DarkSlateBlue,                
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                Margin = new Thickness(2),
                Content = buttonText
            };
            button.Click += clickHandler;
            //_tabGrid.Children.Add(button);
            return button;
        }

        private static Button CreateButton(string buttonText, RoutedEventHandler clickHandler)
        {
            var button = new Button
            {
                //Width = 120,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Top,
                Margin = new Thickness(1),
                Padding = new Thickness(3),
                Content = buttonText
            };
            button.Click += clickHandler;
            //_tabGrid.Children.Add(button);
            return button;
        }

        private static void CreateStretchyGroup(string title, List<Control> items)
        {
            var group = new UniformGrid
            {
                Columns = 1,
                Background = BackgroundBrush,
                Height = 160,                
                Margin = new Thickness(10,10,10,10),
            };

            if(!string.IsNullOrEmpty(title))
                group.Children.Add(CreateTitle(title));

            foreach (var item in items)
            {
                if (item != null)
                    group.Children.Add(item);
            }

            _tabGrid.Children.Add(group);
        }

        private static readonly SolidColorBrush BackgroundBrush = new SolidColorBrush(Color.FromRgb(67,67,67));

        private static void CreateGroup(string title, List<Control> items)
        {
            var group = new StackPanel
            {
                Background = BackgroundBrush,
                Height = 170,
                Margin = new Thickness(7, -13, 0, 0),       
                ClipToBounds = false         
            };

            if (!string.IsNullOrEmpty(title))
                group.Children.Add(CreateTitle(title));

            foreach (var item in items)
            {
                if(item != null)
                    group.Children.Add(item);
            }

            _tabGrid.Children.Add(group);
        }

        static TextBlock CreateTitle(string title)
        {
            return new TextBlock
            {
                Text = title,
                Width = 140,
                Height = 18,
                Padding = new Thickness(0, 2, 0, 0),
                Margin = new Thickness(2.5),
                VerticalAlignment = VerticalAlignment.Center,
                TextAlignment = TextAlignment.Center,
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold
            };
        }

        #endregion
    }
}

