﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trinity.Cache;
using Trinity.Coroutines;
using Trinity.Framework.Avoidance;
using Trinity.Framework.Grid;
using Trinity.Framework.Utilities;

namespace Trinity.Framework
{
    public static class Core
    {
        public static readonly AvoidanceManager Avoidance = new AvoidanceManager();        
        public static readonly Cooldowns Cooldowns = new Cooldowns();
        public static readonly GridUtil Grids = new GridUtil();
        public static readonly PlayerHistory PlayerHistory = new PlayerHistory();
        public static readonly Paragon Paragon = new Paragon();

        public static void Enable()
        {
            Cooldowns.Enable();
            Avoidance.Enable();
            PlayerHistory.Enable();
            Paragon.Enable();
        }

        public static void Disable()
        {
            Cooldowns.Disable();
            Avoidance.Disable();
            PlayerHistory.Disable();
            Paragon.Disable();
        }

    }
}



