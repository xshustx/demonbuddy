﻿using System;
using Trinity.Config;
using Zeta.Game;
using Zeta.Game.Internals.Actors;
using Logger = Trinity.Technicals.Logger;

namespace Trinity.Framework.Utilities
{
    public class Paragon : Utility
    {
        public DateTime LastAssignedParagon = DateTime.MinValue;

        protected override void OnPulse()
        {
            SpendPoints();
        }

        public void SpendPoints()
        {
            if (DateTime.UtcNow.Subtract(LastAssignedParagon).TotalSeconds < 30)
                return;

            if (!ZetaDia.IsInGame || ZetaDia.IsLoadingWorld || !ZetaDia.Me.IsValid)
                return;

            LastAssignedParagon = DateTime.UtcNow;

            for (int i = 0; i < 4; i++)
            {
                ParagonCategory category = (ParagonCategory) i;
                int pointsAvailable = ZetaDia.Me.GetParagonPointsAvailable((ParagonCategory) i);
                if (pointsAvailable != 0)
                {
                    Logger.Log("You have {0} points in the category: {1} available", pointsAvailable, category);

                    switch (category)
                    {
                        case ParagonCategory.PrimaryAttributes:
                            ApplyPoints(Trinity.Settings.Paragon.CoreParagonPriority, pointsAvailable);
                            break;

                        case ParagonCategory.Defense:
                            ApplyPoints(Trinity.Settings.Paragon.DefenseParagonPriority, pointsAvailable);
                            break;

                        case ParagonCategory.Offense:
                            ApplyPoints(Trinity.Settings.Paragon.OffenseParagonPriority, pointsAvailable);
                            break;

                        case ParagonCategory.Utility:
                            ApplyPoints(Trinity.Settings.Paragon.UtilityParagonPriority, pointsAvailable);
                            break;
                    }
                }
            }
        }

        private static void ApplyPoints(ParagonSetting.ParagonCollection source, int pointsAvailable)
        {
            var pointsSpent = 0;

            foreach (var item in source)
            {
                if (pointsSpent >= pointsAvailable)
                {
                    Logger.LogVerbose("Spent all available points for the category '{0}'", item.Category);
                    return;
                }

                var currentlySpent = ZetaDia.Me.GetParagonBonus(item.DynamicType);

                var amount = Math.Min(item.MaxLimit - currentlySpent, pointsAvailable - pointsSpent);

                if (currentlySpent >= item.MaxLimit)
                {
                    Logger.LogVerbose("Skipping {1} ({2}) max limit has been reached (Spent={3} IsLimited={4} Limit={5} LimitMax={6}",
                        amount, item.DisplayName, item.DynamicType, currentlySpent, item.IsLimited, item.Limit, item.MaxLimit);

                    continue;
                }

                if (item.IsLimited)
                {
                    if (currentlySpent >= item.Limit)
                    {
                        Logger.LogVerbose("Skipping {1} ({2}) limit has been reached (Spent={3} IsLimited={4} Limit={5} LimitMax={6}",
                            amount, item.DisplayName, item.DynamicType, currentlySpent, item.IsLimited, item.Limit, item.MaxLimit);

                        continue;
                    }

                    amount = Math.Min(item.Limit, amount);
                }

                if (item.DynamicType == ParagonBonusType.MovementBonusRunSpeed)
                {
                    var bonusSpeedFromItems = ZetaDia.Me.CommonData.MovementScalarTotal;
                    if (bonusSpeedFromItems > 1)
                    {
                        var pctBonus = (int)Math.Round((bonusSpeedFromItems - 1)*100,0, MidpointRounding.AwayFromZero);
                        var pointsNegatedByItems = pctBonus * 2;
                        var effectiveMaxPoints = item.MaxLimit - pointsNegatedByItems; 
                        amount = Math.Min(effectiveMaxPoints, amount);
                        Logger.LogVerbose("Adjusting MovementSpeed based on {0}% contributed by items.", pctBonus);
                    }
                }

                if (amount <= 0)
                {
                    Logger.LogVerbose("Skipping {1} ({2}) spend amount = {0} (Spent={3} IsLimited={4} Limit={5} LimitMax={6}",
                        amount, item.DisplayName, item.DynamicType, currentlySpent, item.IsLimited, item.Limit, item.MaxLimit);

                    continue;
                }

                Logger.LogVerbose("Assigning {0} points to {1} ({2}) (Spent={3} IsLimited={4} Limit={5} LimitMax={6}", 
                    amount, item.DisplayName, item.DynamicType, currentlySpent, item.IsLimited, item.Limit, item.MaxLimit);

                ZetaDia.Me.SpendParagonPoints(item.DynamicType, amount);
                pointsSpent += amount;
            }
        }

    }
}

