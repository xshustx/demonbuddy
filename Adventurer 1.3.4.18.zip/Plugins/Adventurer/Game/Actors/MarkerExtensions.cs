﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Zeta.Game;
using Zeta.Game.Internals;

namespace Adventurer.Game.Actors
{
    public static class MarkerExtensions
    {
        public static string GetDisplayName(this MinimapMarker minimapMarker)
        {
            return string.Empty;

        }
    }
}
