//namespace Adventurer.Game.Rift
//{
//    public enum RiftType
//    {
//        Greater,
//        Nephalem
//    }
//}