﻿namespace Adventurer.Game.Exploration.Experiments
{
    public class AdventurerNavigationProvider
    {
    }
}
