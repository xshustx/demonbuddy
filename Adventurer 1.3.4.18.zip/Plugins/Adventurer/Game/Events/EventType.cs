﻿namespace Adventurer.Game.Events
{
    public enum EventType
    {
        None = 0,
        Pulse,
    }
}