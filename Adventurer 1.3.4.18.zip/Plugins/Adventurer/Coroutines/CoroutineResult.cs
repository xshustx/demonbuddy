﻿namespace Adventurer.Coroutines
{
    public enum CoroutineResult
    {
        Success,
        Failure
    }
}
