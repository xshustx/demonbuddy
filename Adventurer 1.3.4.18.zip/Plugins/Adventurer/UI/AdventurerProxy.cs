﻿namespace Adventurer.UI
{
    class AdventurerProxy
    {
    }
}
