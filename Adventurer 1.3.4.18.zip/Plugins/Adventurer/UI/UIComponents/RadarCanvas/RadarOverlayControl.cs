﻿using Buddy.Overlay.Controls;

namespace Adventurer.UI.UIComponents.RadarCanvas
{
    class RadarOverlayControl : OverlayControl
    {
        //override onr
    }
}
